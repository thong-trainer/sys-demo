<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="content-header">
  <h1>
    <?php echo e(__('title.dashboard')); ?>

    <small><?php echo e(__('title.list_invoices')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li class="active"><?php echo e(__('title.invoices')); ?></li>
  </ol>
</section>

<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>
  <?php 
    $default_currency = Auth::user()->defaultCurrency()
  ?>

  <div class="row">
    <div class="col-lg-12 col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(__('title.list_invoices')); ?></h3>
              <!-- tools box - add new record-->
              <!-- /. tools -->                            
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <!-- form search -->
              <form action="<?php echo e(route('invoice.index')); ?>" method="GET">
                <div class="m-container">
                  <div class="m-left">           
                    <div class="input-group" style="float: left">                                            
                      <select class="form-control" name="status">
                        <option value=""><?php echo e(__('app.status')); ?></option>
                        <?php $__currentLoopData = config('global.invoice_status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>"><?php echo e($status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>                    
                    <div class="input-group" style="float: left;">
                      <button type="submit" class="btn btn-default"><i class="fa fa-filter"></i> <?php echo e(__('title.filter')); ?></button>
                    </div>
                  </div>
                  <div class="m-right">
                    <div class="input-group input-group pull-right" style="width: 300px;">
                      <input type="text" name="search" value="<?php echo e(Request::get('search')?:''); ?>" class="form-control" placeholder="<?php echo e(__('title.search')); ?>">
                      <span class="input-group-btn">
                        <button type="submit" class="btn btn-info btn-flat"><i class="fa fa-search"></i></button>
                        <a href="<?php echo e(route('invoice.index')); ?>" class="btn btn-danger btn-flat"><i class="fa fa-refresh"></i></a>
                      </span>
                    </div>                    
                  </div>
                  <div id="center"></div>
                </div>
              </form>              
              <!-- end form search -->
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <!-- <th style="width: 10px">#</th> -->
                    <th><?php echo e(__('app.invoice_no')); ?></th>
                    <th><?php echo e(__('app.issue_date')); ?></th>
                    <th><?php echo e(__('app.due_date')); ?></th>
                    <th><?php echo e(__('app.customer')); ?></th>
                    <th><?php echo e(__('app.created_by')); ?></th>
                    <th><?php echo e(__('app.grand_total')); ?></th>
                    <th style="width: 100px"><?php echo e(__('app.status')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr style="<?php echo e($item->is_delete == 0 ? '' : 'color:#A8A8A8'); ?>">
                    <!-- <td><?php echo e($key+1); ?> </td>                     -->
                    <td>
                      <a href="<?php echo e(route('invoice.show', $item->id)); ?>/show" title="View Detail"><?php echo e($item->invoice_number); ?> <i class="fa fa-external-link"></i></a>
                    </td>
                    <td><?php echo e($item->issue_date); ?></td>
                    <td><?php echo e($item->due_date); ?></td>
                    <td><?php echo e($item->customer->contact->contact_name); ?></td>
                    <td><?php echo e($item->user->name); ?></td>
                    <td><?php echo e($default_currency->symbol); ?> <?php echo e(number_format($item->grand_total, $default_currency->digit)); ?></td>
                    <td> 
                      <span class="<?php echo e($item->statusColor($item->status)); ?> label-md"><?php echo e($item->status); ?></span>
                    </td>
                  </tr>                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>                
              </table>
            </div>
            <div class="box-footer clearfix">
              <?php echo $__env->make('layouts.pagination', ['data'=>$invoices], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>             
          </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\testing\drc\resources\views/invoices/index.blade.php ENDPATH**/ ?>