<?php 
$currency_symbol = Auth::user()->defaultCurrency()->symbol
?> 
<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
  <h4 class="modal-title"><?php echo e(__('title.edit_product_price')); ?> </h4>
</div>
<form role="form" action="<?php echo e(route('product-price.update', $product_price->id)); ?>" method="POST">
  <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
  <div class="modal-body">
    <?php if($product_price->is_default != 1): ?>
    <div class="form-group <?php if ($errors->has('customer_group_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_group_id'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
      <label><?php echo e(__('app.customer_group')); ?> <span class="required">*</span></label>
      <select class="form-control" name="customer_group_id">
        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($item->id); ?>" <?php if($item->id == $product_price->customer_group_id): ?> selected <?php endif; ?>><?php echo e($item->group_name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>  
      <?php if ($errors->has('customer_group_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_group_id'); ?>
      <span class="help-block"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                                            
    </div>
    <?php endif; ?>

    <div class="form-group">
      <label for="price"><?php echo e(__('app.price')); ?> </label>
      <div class="input-group">
        <span class="input-group-addon"><b><?php echo e($currency_symbol); ?></b></span>
        <input type="number" step="any" id="price" name="price" class="form-control" min="0" value="<?php echo e($product_price->price); ?>" required>
      </div>                                             
    </div> 

    <?php if($product_price->is_default != 1): ?>
    <div class="form-group <?php if ($errors->has('minimum_qty')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('minimum_qty'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
      <label for="price"><?php echo e(__('app.minimum_qty')); ?> <span class="required">*</span></label>
      <input type="number" class="form-control" id="minimum_qty" name="minimum_qty" min="1" value="<?php echo e($product_price->minimum_qty); ?>" required>
      <?php if ($errors->has('minimum_qty')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('minimum_qty'); ?>
      <span class="help-block"><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
    </div>                            
    <?php endif; ?>

  </div>
  <div class="modal-footer">
    <?php if(Auth::user()->allowCreate(config('global.modules.role'))): ?>
    <button type="submit" class="btn btn-primary"><?php echo e(__('title.save')); ?></button>&nbsp;&nbsp;&nbsp;
    <?php endif; ?>            
    <a href="#model-popup" class="btn btn-default"  data-toggle="modal"><?php echo e(__('title.cancel')); ?></a>
  </div>
</form>



<?php $__env->startSection('js'); ?>
<!-- date-range-picker -->
<script src="<?php echo e(asset('bower_components/moment/min/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('bower_components/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>
<!-- bootstrap datepicker -->
<script src="<?php echo e(asset('bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js')); ?>"></script>
<!-- bootstrap color picker -->
<script src="<?php echo e(asset('bower_components/bootstrap-colorpicker/dist/js/bootstrap-colorpicker.min.js')); ?>"></script>
<!-- bootstrap time picker -->
<script src="<?php echo e(asset('plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
<script type="text/javascript">   
$(document).ready(function() {
    //Date picker
    $('.datepicker').datepicker({
      autoclose: true
    })
});  
</script>
<?php $__env->stopSection(); ?><?php /**PATH D:\personal\lyly\papapos\resources\views/product-prices/update.blade.php ENDPATH**/ ?>