<?php
$company = Auth::user()->companyInfo();
?>
<div id="content">
	<section class="invoice">
    <div class="row">
      <div class="col-xs-12">
        <h2 class="page-header">
           <b>Test</b>
          <small class="pull-right"><?php echo e(__('app.date')); ?>: <?php echo e($item->quotation_date); ?></small>
        </h2>
      </div>
      <!-- /.col -->
    </div>
    <!-- info row -->
    <div class="row invoice-info">
      <div class="col-sm-4 invoice-col">
        <?php echo e(__('app.from')); ?>

        <address>
          <strong><?php echo e($company->company_name); ?></strong><br>
          <?php echo e($company->address); ?><br>
          <?php echo e(__('app.phone')); ?>: <?php echo e($company->telephone); ?><br>
          <?php echo e(__('app.email')); ?>: <?php echo e($company->email); ?>

        </address>
      </div>
      <!-- /.col -->
      <div class="col-sm-4 invoice-col">
        <?php echo e(__('app.to')); ?>

        <address>
          <strong><?php echo e($item->customer->contact->contact_name); ?></strong><br>
          <?php echo e($item->customer->contact->main_address); ?><br>
          Phone: <?php echo e($item->customer->contact->primary_telephone); ?><br>
          Email: <?php echo e($item->customer->contact->email); ?>

        </address>
      </div>
      <!-- /.col -->
      <div class="col-sm-4 invoice-col">
        <!-- <b>Invoice: #12022</b><br> -->
        <br>
        <b><?php echo e(__('app.quotation_no')); ?>:</b> <?php echo e($item->quotation_number); ?><br>
        <b><?php echo e(__('app.validity')); ?>:</b> <?php echo e($item->validity_date); ?><br>
        <b><?php echo e(__('app.account_no')); ?>:</b> <?php echo e($item->customer->code); ?>

      </div>
      <!-- /.col -->
    </div>

    <div class="row">
      <div class="col-xs-12 table-responsive">
        <table class="table table-striped">
          <thead>
          <tr>
            <th>#</th>
            <th><?php echo e(__('app.description')); ?></th>
            <th><?php echo e(__('app.qty')); ?></th>
            <th><?php echo e(__('app.price')); ?></th>
            <th><?php echo e(__('app.tax')); ?></th>
            <th><?php echo e(__('app.subtotal')); ?></th>
          </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($key + 1); ?></td>
              <td><?php echo e($detail->product_name); ?></td>
              <td><?php echo e(number_format($detail->unit_price, 2)); ?></td>
              <td><?php echo e($detail->qty); ?></td>
              <td><?php echo e($detail->tax); ?>%</td>
              <td><?php echo e(number_format($detail->subtotal, 2)); ?></td>
            </tr>            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
          </tbody>
        </table>
      </div>
      <!-- /.col -->
    </div>
</section>
</div>
<div id="editor"></div>
<button id="cmd">generate PDF</button>
<script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.2/jspdf.min.js"></script>
<script type="text/javascript">
var doc = new jsPDF();
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};

$('#cmd').click(function () {
    doc.fromHTML($('#content').html(), 15, 15, {
        'width': 170,
            'elementHandlers': specialElementHandlers
    });
    doc.save('sample-file.pdf');
});
	

</script><?php /**PATH D:\personal\lyly\papapos\resources\views/quotations/pdfview.blade.php ENDPATH**/ ?>