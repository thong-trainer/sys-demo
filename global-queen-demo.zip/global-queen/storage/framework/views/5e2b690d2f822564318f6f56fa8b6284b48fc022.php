<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.dashboard')); ?>

    <small><?php echo e(__('title.list_purchase_orders')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li class="active"><?php echo e(__('title.purchase_orders')); ?></li>
  </ol>
</section>
<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>    
  <div class="row">
    <div class="col-lg-12 col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(__('title.list_purchase_orders')); ?></h3>
              <!-- tools box - add new record-->
              <?php if(Auth::user()->allowCreate(config('global.modules.purchase'))): ?>
              <div class="pull-right box-tools">
                <a href="<?php echo e(route('purchase.create')); ?>" class="btn btn-primary btn-sm" data-widget="add-new" data-toggle="tooltip"
                        title="Add New"><i class="fa fa-plus"></i> <?php echo e(__('title.add_new')); ?></a>
              </div>
              <?php endif; ?>
              <!-- /. tools -->                            
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <!-- form search -->
              <!-- end form search -->
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th style="width: 10px">#</th>
                    <th><?php echo e(__('app.role')); ?></th>
                    <th><?php echo e(__('app.description')); ?></th>
                    <th style="width: 40px"><?php echo e(__('app.action')); ?></th>
                  </tr>
                </thead>
                <tbody>
               
                </tbody>                
              </table>
            </div>
          </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\papapos\resources\views/purchases/index.blade.php ENDPATH**/ ?>