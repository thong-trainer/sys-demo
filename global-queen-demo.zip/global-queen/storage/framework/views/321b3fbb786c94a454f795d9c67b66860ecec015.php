<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php 
$currency = Auth::user()->defaultCurrency()
?>

<?php if(Auth::user()->allowCreate(config('global.modules.stock'))): ?>
  <div class="modal fade" id="modelUpdateQty" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <form action="<?php echo e(route('stock.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>                       
        <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">  
        <input type="hidden" name="status" value="<?php echo e(config('global.stock_status.stock_in')); ?>">  
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title"><?php echo e(__('title.update_qty_on_hand')); ?> </h4>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label for="name"><?php echo e(__('app.new_qty')); ?> <span class="required">*</span></label>
              <input type="number" id="qty" name="qty" class="form-control" min="1" value="" required>
            </div> 
            <?php if(Auth::user()->allowMultiStorageLocations()): ?>
            <div class="form-group">
              <label><?php echo e(__('app.location')); ?> </label>
              <select class="form-control" name="location_id">
                <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->location_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>              
            </div>
            <?php else: ?>
            <input type="hidden" name="location_id" value="<?php echo e($locations[0]->id); ?>">
            <?php endif; ?>            
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary"><?php echo e(__('title.save_changes')); ?></button>
            <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
          </div>
        </div>
      </form>
    </div>
  </div>
<?php endif; ?> 
<section class="content-header">
  <h1>
    <?php echo e(__('title.view_product')); ?> <small>#<?php echo e($product->id); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('product.index')); ?>"><?php echo e(__('title.products')); ?></a></li>
    <li class="active"><?php echo e(__('title.view')); ?></li>
  </ol>
</section>
  <!-- href="#modelPopup" data-toggle="modal" -->
<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>   
  <div class="row pull-right">
    <div class="col-sm-12">
      <?php if(Auth::user()->allowVariant()): ?>
      <a id="variant" class="btn btn-app btn-app-white"> 
        <span class="badge bg-red"><?php echo e($product->hasVariant() ? '' : 'setup'); ?></span>
        <i class="fa fa-sitemap"></i> <?php echo e(__('title.variants')); ?>

      </a>       
      <?php endif; ?>

      <?php if(Auth::user()->allowVariant() && Auth::user()->allowEdit(config('global.modules.product_price'))): ?>
      <a id="pricing" href="<?php echo e(route('variant.extra-price.list', $product->id)); ?>" class="btn btn-app btn-app-white" >
        <span class="badge bg-red"></span>
        <i class="fa fa-dollar"></i> <?php echo e(__('title.extra_prices')); ?>

      </a>
      <?php endif; ?>
      
      <?php if(Auth::user()->allowStock() && Auth::user()->allowCreate(config('global.modules.stock'))): ?>
      <a href="#modelUpdateQty" data-toggle="modal" class="btn btn-app btn-app-white" >
        <span class="badge bg-yellow">stock in</span>
        <i class="fa fa-pencil-square-o"></i> <?php echo e(__('title.update_qty')); ?>

      </a>       
      <a href="<?php echo e(route('stock.show', $product->id)); ?>/show" class="btn btn-app btn-app-white" >
        <span class="badge bg-aqua"><?php echo e($product->onHand()); ?></span>
        <i class="fa fa-cubes"></i> <?php echo e(__('title.on_hand')); ?>

      </a>   
      <?php endif; ?>
      <a class="btn btn-app btn-app-white" >
        <span class="badge bg-green"><?php echo e($product->sold()); ?></span>
        <i class="fa fa-signal"></i> <?php echo e(__('title.sold')); ?>

      </a>  
             
    </div>
  </div>  
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(__('title.product_information')); ?></h3>   
          <?php if(Auth::user()->allowEdit(config('global.modules.product'))): ?>          
            <div class="pull-right box-tools">

              <?php if($product->is_release == 0): ?>
              <a href="#modelRelease" class="btn btn-success btn-sm" data-toggle="modal" data-toggle="tooltip" title="Release"><i class="fa fa-check"></i> <?php echo e(__('title.release')); ?></a>&nbsp;&nbsp;   
              <div class="modal fade" id="modelRelease" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                      <h4 class="modal-title"><?php echo e(__('title.release')); ?> (<?php echo e($product->product_name); ?>)</h4>
                    </div>
                    <div class="modal-body">
                    <?php echo e(__('message.release_confirmation')); ?>

                    <p class="margin"><i class="fa fa-info"></i> <?php echo app('translator')->getFromJson('message.release_info'); ?> </p>
                    </div>
                    <div class="modal-footer">
                      <form action="<?php echo e(route('product.release', $product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>                        
                        <button type="submit" class="btn btn-success"><?php echo e(__('title.yes_release')); ?></button>
                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <?php else: ?>
              <a href="#modelDeactivate" class="btn btn-danger btn-sm" data-toggle="modal" data-toggle="tooltip" title="Deactivate"><i class="fa fa-close"></i> <?php echo e(__('title.deactivate')); ?></a>&nbsp;&nbsp;   
              <div class="modal fade" id="modelDeactivate" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                      <h4 class="modal-title"><?php echo e(__('title.deactivate')); ?> (<?php echo e($product->product_name); ?>)</h4>
                    </div>
                    <div class="modal-body">
                    <?php echo e(__('message.deactivate_confirmation')); ?>

                    <p class="margin"><i class="fa fa-info"></i> <?php echo app('translator')->getFromJson('message.deactivate_warning'); ?> </p>
                    </div>
                    <div class="modal-footer">
                      <form action="<?php echo e(route('product.deactivate', $product->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>                        
                        <button type="submit" class="btn btn-danger"><?php echo e(__('title.deactivate')); ?></button>
                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>                            
              <?php endif; ?>                                 
              <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="btn btn-default btn-sm" data-toggle="tooltip" title="Edit"><i class="fa fa-pencil"></i> <?php echo e(__('title.edit')); ?></a>
            </div>
          <?php endif; ?>                        
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="#" method="POST">
            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-12 col-sm-12">                 
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="form-group">
                      <img class="img-upload" id="blah" src="<?php echo e(url($product->image_url)); ?>" alt="your image" />
                    </div>                    
                  </div>
                  <div class="col-lg-8 col-md-8 col-sm-12">      
                    <div class="form-group ">
                      <label class="control-label"><i class="fa fa-check"></i> <?php echo e($product->product_type); ?></label>
                      <input type="text" class="form-control big-input" id="name" name="product_name" value="<?php echo e($product->product_name); ?>" readonly>
                    </div>
                    <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group">
                          <label class="control-label"><?php echo e(__('app.category_name')); ?></label>
                          <input type="text" class="form-control" value="<?php echo e($product->category->category_name); ?>" readonly>
                        </div> 
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-12">
                       <div class="form-group">
                        <label class="control-label"><?php echo e(__('app.dimension_group')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($product->dimensionGroup->dimension_group); ?>" readonly>
                      </div> 
                    </div>                        
                  </div>
                  <div class="form-group" style="margin-bottom:0px">
                    <label for="cost"><?php echo e(__('app.cost')); ?>: <?php echo e($currency->symbol); ?> <?php echo e($product->cost ? number_format($product->cost, $currency->digit): 'N/A'); ?></label>
                  </div>                                   
                  </div>                    
                </div>
                <div class="form-group">
                  <label for="note"><?php echo e(__('app.notes')); ?> </label>
                  <textarea readonly type="text" rows="5" class="form-control" id="notes" name="note"><?php echo e(old('notes') ?: $product->notes); ?></textarea>
                </div>     
              </div>
              <div class="col-lg-6 col-md-12 col-sm-12">                 
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                      <label for="barcode"><?php echo e(__('app.barcode')); ?> </label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-barcode"></i></span>
                        <input type="text" id="barcode" name="barcode" class="form-control" value="<?php echo e($product->barcode); ?>" readonly>
                      </div>                                               
                    </div> 
                    <div class="form-group">
                      <label for="ref_number"><?php echo e(__('app.ref_number')); ?> </label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-link"></i></span>
                        <input type="text" class="form-control" value="<?php echo e($product->ref_number); ?>" readonly>
                      </div>                            
                    </div>   
                    <div class="form-group">
                      <label for="customer_tax"><?php echo e(__('app.customer_tax')); ?> </label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                        <input type="number" class="form-control" value="<?php echo e($product->customer_tax); ?>" readonly>
                      </div>                                                 
                    </div>                                                           
                    <div class="form-group">
                      <label for="sale_unit_id"><?php echo e(__('app.sale_unit')); ?></label>
                      <input type="text" class="form-control" value="<?php echo e($product->saleUnit->unit_name); ?>" readonly>
                    </div> 
                    <div class="form-group">
                      <label>
                        <input disabled type="checkbox" class="flat-red" value="1" name="is_pos" <?php if($product->is_pos == 1): ?> checked <?php endif; ?>>
                        <?php echo e(__('app.pos_available')); ?>

                      </label>
                    </div>
                  </div>                        
                </div>  
              </div>           
            </div>
            <div class="row">
              <div class="col-md-9">      
                <!-- /.box -->
                <div class="box box-solid">
                  <div class="box-header with-border" style="padding-left: 0px">
                    <h3 class="box-title"><i class="fa fa-list"></i> <?php echo e(__('app.product_price_list')); ?></h3>
                  </div>
                  <!-- /.box-header -->
                  <div class="box-body" style="padding: 0px">          
                      <table id="pricing-table" class="table table-striped table-hover">
                        <thead class="thead-dark">
                          <tr>
                            <th><?php echo e(__('app.customer_group')); ?></th>
                            <th><?php echo e(__('app.price')); ?></th>
                            <th><?php echo e(__('app.minimum_qty')); ?></th>
                            <!-- <th><?php echo e(__('app.start_date')); ?></th> -->
                            <!-- <th><?php echo e(__('app.end_date')); ?></th> -->
                            <th style="width: 70px"></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $product->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td> <?php echo e($item->customerGroup->group_name); ?> </td>
                              <td><span class="label label-success"><?php echo e($currency->symbol); ?> <?php echo e(number_format($item->price, $currency->digit)); ?></span>  </td>
                              <td> <?php echo e($item->minimum_qty); ?> </td>
                              <!-- <td> <?php echo e($item->start_date); ?> </td> -->
                              <!-- <td> <?php echo e($item->end_date ?: 'N/A'); ?> </td> -->
                              <td>
                                <?php if(Auth::user()->allowEdit(config('global.modules.product_price'))): ?>
                                <a href="#model-popup" data-price-id="<?php echo e($item->id); ?>" class="edit-price" title="Edit"><i class="fa fa-pencil text-primary"></i></a>
                                <?php endif; ?>                               
                                  <?php if(Auth::user()->allowDelete(config('global.modules.product_price'))): ?>
                                    <?php if($item->is_default == 0): ?>
                                      <span style="padding: 5px">|</span><a href="#model-delete-<?php echo e($item->id); ?>" data-toggle="modal" title="Remove"><i class="fa fa-trash text-danger remove"></i></a>
                                    <?php endif; ?>                                  
                                    <div class="modal fade" id="model-delete-<?php echo e($item->id); ?>" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                                      <div class="modal-dialog">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                            <h4 class="modal-title"><?php echo e(__('title.delete')); ?></h4>
                                          </div>
                                          <div class="modal-body">
                                            <?php echo e(__('message.delete_confirmation')); ?>

                                            <p class="margin"><i class="fa fa-warning"></i> <?php echo app('translator')->getFromJson('message.delete_warning'); ?> </p>
                                          </div>
                                          <div class="modal-footer">
                                            <form role="form" action="<?php echo e(route('product-price.delete', $item->id)); ?>" method="POST">
                                              <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                              <button type="submit" class="btn btn-danger save-cancel"><?php echo e(__('title.delete')); ?></button>
                                              <button type="button" class="btn btn-default save-cancel" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
                                            </form>
                                          </div>
                                        </div>
                                      </div>
                                    </div>                                                             
                                <?php endif; ?>
                              </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php if(Auth::user()->allowPriceList()): ?>
                            <?php if(Auth::user()->allowCreate(config('global.modules.product_price'))): ?>
                              <tr>
                                <td colspan="6">
                                  <a href="#model-popup" id="new-price" href="" title="Add New"><i class="fa fa-plus text-primary new"></i> <?php echo e(__('title.add_price')); ?></a></td>
                              </tr>
                            <?php endif; ?>
                          <?php endif; ?>
                        </tbody>
                      </table>
                  </div>
                  <!-- /.box-body -->
                </div>
                <!-- /.box -->                
              </div>
            </div>
          </div>
        </form>
        </div>
      </div>      
    </div>
  </div>
</section>

<div class="modal fade" id="model-popup" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" id="modal-content">
    </div>
  </div>
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">   
$(document).ready(function() {


  $('#variant').click(function () {
      var url = "<?php echo e(route('ajax.variant.list', [':product_id', ':dimension_group_id'])); ?>";
      url = url.replace(':product_id', "<?php echo e($product->id); ?>");
      url = url.replace(':dimension_group_id', "<?php echo e($product->dimension_group_id); ?>");
      console.log(url);
      showModal(url);
  });

  $('#new-price').click(function () {
      var url = "<?php echo e(route('ajax.price.create', [':product_id'])); ?>";
      url = url.replace(':product_id', "<?php echo e($product->id); ?>");
      console.log(url);
      showModal(url);
  });  
    
  $('body').on('click', '.edit-price', function(){
      var priceId = $(this).data('price-id');
      var url = "<?php echo e(route('ajax.price.edit', [':price_id'])); ?>";
      url = url.replace(':price_id', priceId);
      console.log(url);
      showModal(url);    

  });   

  function showModal(url) {
    $.ajax({
        url: url,
        success: function(data){
          $("#modal-content").html(data);
          $("#model-popup").modal('show');
        }   
    });
  }

});  
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\papapos\resources\views/products/show.blade.php ENDPATH**/ ?>