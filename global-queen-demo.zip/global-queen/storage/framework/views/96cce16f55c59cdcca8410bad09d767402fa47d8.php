<div class="pagination pagination-sm no-margin pull-right">
	<?php echo e($data->links()); ?>

</div>
<?php /**PATH /Users/leykamthong/Desktop/projects/selingmix.com/drc/resources/views/layouts/pagination.blade.php ENDPATH**/ ?>