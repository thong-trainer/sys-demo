<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.edit_user')); ?> <small>#<?php echo e($user->id); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('user.index')); ?>"><?php echo e(__('title.users')); ?></a></li>
    <li class="active"><?php echo e(__('title.edit')); ?></li>
  </ol>
</section>

<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>  

  <?php if($user->is_enable == 0): ?>
  <div class="callout callout-danger">
    <h4><i class="fa fa-info-circle"></i> &nbsp;<?php echo e(__('title.deactivate')); ?></h4>
    <p><?php echo app('translator')->getFromJson('message.deactivate_info'); ?></p>
  </div>  
  <?php endif; ?>
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(__('title.user_information')); ?></h3>      
            <div class="pull-right box-tools">

              <?php if($user->is_enable == 0): ?>
              <a href="#modelRelease" class="btn btn-success btn-sm" data-toggle="modal" data-toggle="tooltip" title="Release"><i class="fa fa-check"></i> <?php echo e(__('title.active_account')); ?></a>&nbsp;&nbsp;   
              <div class="modal fade" id="modelRelease" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                      <h4 class="modal-title"><?php echo e(__('title.active_account')); ?> (<?php echo e($user->name); ?>)</h4>
                    </div>
                    <div class="modal-body">
                    <?php echo e(__('message.active_confirmation')); ?>

                    </div>
                    <div class="modal-footer">
                      <form action="<?php echo e(route('user.active', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>                        
                        <button type="submit" class="btn btn-success"><?php echo e(__('title.active_account')); ?></button>
                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              <?php else: ?>
              <a href="#modelDeactivate" class="btn btn-danger btn-sm" data-toggle="modal" data-toggle="tooltip" title="Deactivate"><i class="fa fa-close"></i> <?php echo e(__('title.deactivate')); ?></a>&nbsp;&nbsp;   
              <div class="modal fade" id="modelDeactivate" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                      <h4 class="modal-title"><?php echo e(__('title.deactivate')); ?> (<?php echo e($user->name); ?>)</h4>
                    </div>
                    <div class="modal-body">
                    <?php echo e(__('message.deactivate_confirmation')); ?>

                    </div>
                    <div class="modal-footer">
                      <form action="<?php echo e(route('user.deactivate', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>                        
                        <button type="submit" class="btn btn-danger"><?php echo e(__('title.deactivate')); ?></button>
                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>                            
              <?php endif; ?>                                 
            </div>                
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="<?php echo e(route('user.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
          
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-8 col-sm-12">

                <div class="form-group <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="name"><?php echo e(__('app.username')); ?> <span class="required">*</span></label>
                  <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')?:$user->name); ?>" required>
                  <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>                  
                <div class="form-group <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="email"><?php echo e(__('app.email')); ?> <span class="required">*</span></label>
                  <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')?:$user->email); ?>" readonly>
                  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                  
                </div>
                <div class="form-group">
                  <label for="telephone"><?php echo e(__('app.telephone')); ?></label>
                  <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo e(old('telephone')?:$user->telephone); ?>">
                </div>                     
                <div class="form-group <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                      <label><?php echo e(__('app.role')); ?> <span class="required">*</span></label>
                      <select class="form-control" name="role">
                        <option value="0"><?php echo e(__('app.choose_option')); ?></option>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('role') || $user->role_id == $item->id): ?> selected <?php endif; ?>><?php echo e($item->role_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>  
                      <?php if ($errors->has('role')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role'); ?>
                        <span class="help-block"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                                            
                    </div>
                  </div>
                </div>
                <?php if(Auth::user()->allowMultiStorageLocations()): ?>
                <div class="form-group <?php if ($errors->has('location_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location_id'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12">
                      <label><?php echo e(__('app.location')); ?> <span class="required">*</span></label>
                      <select class="form-control" name="location_id">
                        <option value="0"><?php echo e(__('app.choose_option')); ?></option>
                        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('location_id') || $user->location_id == $item->id): ?> selected <?php endif; ?> ><?php echo e($item->location_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>  
                      <?php if ($errors->has('location_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location_id'); ?>
                        <span class="help-block"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                                            
                    </div>
                  </div>
                </div>   
                <?php else: ?>
                <input type="hidden" name="location_id" value="<?php echo e($user->location_id); ?>">
                <?php endif; ?>                     
                <div class="form-group">
                  <label>
                    <input type="radio" value="male" name="gender" class="flat-red" <?php if(old('gender') == 'male' || $user->gender == 'male'): ?> checked <?php endif; ?>>
                    <?php echo e(__('app.male')); ?>

                  </label>&nbsp;&nbsp;&nbsp;
                  <label>
                    <input type="radio" value="female" name="gender" class="flat-red" <?php if(old('gender') == 'female' || $user->gender == 'female'): ?> checked <?php endif; ?>>
                    <?php echo e(__('app.female')); ?>

                  </label>
                </div>                  

              </div>                

              <div class="col-lg-6 col-md-4 col-sm-12">
                <div class="form-group">
                  <img id="blah" src="<?php echo e(url($user->image_url)); ?>" width="150px" height="150px;" alt="your image" /> <br/><br/>
                  <input type='file' id="imgInp" name="file_upload" />
                </div>
              </div>                  
            </div>

          </div>

          <div class="box-footer">
            <a href="<?php echo e(route('user.index')); ?>" class="btn btn-default"><?php echo e(__('title.cancel')); ?></a>&nbsp;&nbsp;&nbsp;
            <?php if(Auth::user()->allowEdit(config('global.modules.user'))): ?>
            <button type="submit" class="btn btn-primary"><?php echo e(__('title.save_changes')); ?></button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">   
  function readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
          $('#blah').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  $("#imgInp").change(function(){
    readURL(this);
  });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\drc\resources\views/setups/users/update.blade.php ENDPATH**/ ?>