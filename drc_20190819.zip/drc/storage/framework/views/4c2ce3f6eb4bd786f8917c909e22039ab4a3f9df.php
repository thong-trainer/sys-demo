<tr>
  <td>                              
    <?php echo e($product_name); ?> <a href="#" title="View Detail"><i class="fa fa-external-link"></i></a>
    <input type="hidden" name="product_id_array[]" value="<?php echo e($product_id); ?>">
    <input type="hidden" name="product_name_array[]" value="<?php echo e($product_name); ?>">
    <input type="hidden" name="current_currency_id" value="<?php echo e($currency->id); ?>">
  </td>
  <td>
    <?php echo e($currency->symbol); ?> <?php echo e(number_format($price, $currency->digit)); ?>

    <input type="hidden" name="price_array[]" value="<?php echo e($price); ?>">
  </td>
  <td>
    <input style="width: 70px" type="number" name="qty_array[]" min="1" value="<?php echo e($qty); ?>" class="qty" readonly>
  </td>
  <td>
    <?php echo e($tax); ?>

    <input style="width: 70px" type="hidden" name="tax_array[]" value="<?php echo e($tax); ?>">
  </td>                  
  <td>
    <?php echo e($currency->symbol); ?> <?php echo e(number_format($subtotal, $currency->digit)); ?>

    <input type="hidden" name="subtotal_array[]" value="<?php echo e($subtotal); ?>">
  </td>
  <td>
    <a href="#" title="Remove" class="remove"><i class="fa fa-trash text-danger"></i></a>
  </td>
</tr><?php /**PATH D:\personal\lyly\papapos\resources\views/quotations/row.blade.php ENDPATH**/ ?>