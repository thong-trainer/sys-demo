<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.new_product')); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('product.index')); ?>"><?php echo e(__('title.products')); ?></a></li>
    <li class="active"><?php echo e(__('title.create')); ?></li>
  </ol>
</section>


<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>  
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(__('title.product_information')); ?></h3>            
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="<?php echo e(route('product.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-12 col-sm-12">
                 
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="form-group">
                      <img class="img-upload" id="blah" src="<?php echo e(url(config('global.paths.product'))); ?>/no-image-placeholder.jpg" alt="your image" />
                      <input type='file' id="imgInp" name="file_upload" class="hide-file-name" accept="image/png, image/jpeg"/>
                      <input class="btn-upload" type="button" value="Browse" onclick="document.getElementById('imgInp').click();" />
                    </div>                    
                  </div>
                  <div class="col-lg-8 col-md-8 col-sm-12">
                    <div class="form-group <?php if ($errors->has('product_type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_type'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <label>
                        <?php if(!old('product_type') && old('product_type') == 'storable' || old('product_type') != 'service'): ?>
                        <input type="radio" value="storable" name="product_type" class="flat-red" checked>
                        <?php else: ?>
                        <input type="radio" value="storable" name="product_type" class="flat-red">
                        <?php endif; ?>
                        <?php echo e(__('app.storable')); ?>

                      </label>&nbsp;&nbsp;&nbsp;                                      
                      <label>
                        <?php if(!old('product_type') && old('product_type') == 'service'): ?>
                        <input type="radio" value="service" name="product_type" class="flat-red" checked>
                        <?php else: ?>
                        <input type="radio" value="service" name="product_type" class="flat-red">
                        <?php endif; ?>
                        <?php echo e(__('app.service')); ?>

                      </label>
                    </div>          
                    <div class="form-group <?php if ($errors->has('product_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_name'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <input type="text" class="form-control big-input" id="name" name="product_name" value="<?php echo e(old('product_name')); ?>" placeholder="<?php echo e(__('app.name')); ?>" required>
                      <?php if ($errors->has('product_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('product_name'); ?>
                      <span class="help-block"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                    </div>
                    <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group <?php if ($errors->has('category_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category_id'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                          <select class="form-control select2" name="category_id">
                            <option value="0"><?php echo e(__('app.category')); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('category_id')): ?> selected <?php endif; ?>><?php echo e($item->category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>   
                          <?php if ($errors->has('category_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category_id'); ?>
                          <span class="help-block"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                                         
                        </div> 
                      </div>

                      <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group <?php if ($errors->has('dimension_group_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dimension_group_id'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                          <select class="form-control select2" name="dimension_group_id">
                            <option value="0"><?php echo e(__('app.dimension_group')); ?></option>
                            <?php $__currentLoopData = $dimension_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('dimension_group_id')): ?> selected <?php endif; ?>><?php echo e($item->dimension_group); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>   
                          <?php if ($errors->has('dimension_group_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dimension_group_id'); ?>
                          <span class="help-block"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                                         
                        </div> 
                      </div>                        
                    </div>
                    <!-- assign variable -->
                    <?php 
                      $currency_symbol = Auth::user()->defaultCurrency()->symbol
                    ?>
                    <!-- end assign variable -->
                    <div class="row">
                      <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group <?php if ($errors->has('sale_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sale_price'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                          <label for="sale_price"><?php echo e(__('app.sale_price')); ?> <span class="required">*</span></label>
                          <div class="input-group">
                            <span class="input-group-addon"><b><?php echo e($currency_symbol); ?></b></span>
                            <input type="number" step="any" id="sale_price" name="sale_price" class="form-control" value="<?php echo e(old('sale_price') ?: 0); ?>" min="0" required>
                          </div>                         
                          <?php if ($errors->has('sale_price')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('sale_price'); ?>
                          <span class="help-block"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                          
                        </div>                                                
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-12">
                        <div class="form-group <?php if ($errors->has('cost')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cost'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                          <label for="cost"><?php echo e(__('app.cost')); ?> <span class="required">*</span></label>
                          <div class="input-group">
                            <span class="input-group-addon"><b><?php echo e($currency_symbol); ?></b></span>
                            <input type="number" step="any" id="cost" name="cost" class="form-control" value="<?php echo e(old('cost') ?: 0); ?>" min="0" required>
                          </div>                         
                          <?php if ($errors->has('cost')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('cost'); ?>
                          <span class="help-block"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                          
                        </div>                                                
                      </div>                                    
                    </div>
                  </div>                    
                </div>
                <div class="form-group">
                  <label for="note"><?php echo e(__('app.notes')); ?> </label>
                  <textarea type="text" rows="6" class="form-control" id="notes" name="note"><?php echo e(old('notes')); ?></textarea>
                </div>     
              </div>

              <div class="col-lg-6 col-md-12 col-sm-12">                 
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                      <label for="barcode"><?php echo e(__('app.barcode')); ?> </label>
                      <div class="input-group <?php if ($errors->has('barcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('barcode'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                        <span class="input-group-addon"><i class="fa fa-barcode"></i></span>
                        <input type="text" id="barcode" name="barcode" class="form-control" value="<?php echo e(old('barcode')); ?>">
                      </div>
                      <?php if ($errors->has('barcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('barcode'); ?>
                      <span class="help-block"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                                                    
                    </div> 
                    <div class="form-group">
                      <label for="ref_number"><?php echo e(__('app.ref_number')); ?> </label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-link"></i></span>
                        <input type="text" id="ref_number" name="ref_number" class="form-control" value="<?php echo e(old('ref_number')); ?>">
                      </div>                            
                    </div>     
                    <div class="form-group <?php if ($errors->has('customer_tax')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_tax'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <label for="customer_tax"><?php echo e(__('app.customer_tax')); ?> </label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-percent"></i></span>
                        <input type="number" id="customer_tax" name="customer_tax" class="form-control" value="<?php echo e(old('customer_tax') ?: 0); ?>" min="0" max="100">
                      </div>                         
                      <?php if ($errors->has('customer_tax')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('customer_tax'); ?>
                      <span class="help-block"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                          
                    </div>                                               
                    <div class="form-group">
                      <label for="sale_unit_id"><?php echo e(__('app.sale_unit')); ?></label>
                      <select class="form-control select2" name="sale_unit_id">
                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('sale_unit_id')): ?> selected <?php endif; ?>><?php echo e($item->unit_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>                                           
                    </div>    
                    <div class="form-group">
                      <label>
                        <input type="checkbox" class="flat-red" value="1" name="is_pos" checked>
                        <?php echo e(__('app.pos_available')); ?>

                      </label>
                    </div>
                  </div>                        
                </div>  
              </div>           
            </div>
          </div>
          <div class="box-footer">
            <a href="<?php echo e(route('product.index')); ?>" class="btn btn-default"><?php echo e(__('title.cancel')); ?></a>&nbsp;&nbsp;&nbsp;
            <?php if(Auth::user()->allowCreate(config('global.modules.product'))): ?>
            <button type="submit" class="btn btn-primary"><?php echo e(__('title.save')); ?></button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">   
$(document).ready(function() {

  function readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
          $('#blah').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  $("#imgInp").change(function(){
    readURL(this);
  });    
});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\testing\drc\resources\views/products/create.blade.php ENDPATH**/ ?>