<option value="0">{{ __('app.contact') }}</option>
@foreach($contacts as $item)
<option value="{{ $item->id }}" @if($item->id == old('contact')) selected @endif>{{ $item->contact_name }}</option>
@endforeach