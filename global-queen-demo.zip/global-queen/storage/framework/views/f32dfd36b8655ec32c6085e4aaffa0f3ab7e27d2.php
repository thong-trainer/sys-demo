<?php 
  $last_dimension_id = 0;
?>
<div class="row">
  <div class="col-md-6">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="form-group">
        <?php if($last_dimension_id != $variant->dimension_id): ?>
        <label for="name"><?php echo e($variant->dimension->dimension_name); ?><span class="required">*</span></label>
        <?php endif; ?>
        <div class="radio">
          <label>
            <input class="dimension-radio" type="radio" value="<?php echo e($variant->id); ?>" name="<?php echo e($variant->dimension->dimension_name); ?>" <?php if($variant->extra_price == 0): ?> checked <?php endif; ?>>
            <?php echo e($variant->value); ?> 
            <?php if($variant->extra_price > 0): ?>
              <span class="badge bg-green" title="Extra Price">+ <?php echo e($currency->symbol); ?> <?php echo e(number_format($variant->extra_price, $currency->digit)); ?></span>
            <?php endif; ?>
          </label>
        </div>
      </div> 
      <?php 
        $last_dimension_id =  $variant->dimension_id;    
      ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
  </div>
  <div class="col-md-6">
    <label id="price" style="font-size: 22px;"><?php echo e($currency->symbol); ?> <?php echo e(number_format($default_price, $currency->digit)); ?></label>  
    <div class="input-group input-group" style="width: 150px">                  
      <span class="input-group-btn">
        <button id="qty-down" type="button" class="btn btn-info btn-flat"><i class="fa fa-minus"></i></button>
      </span>                  
      <input type="text" id="qty" name="qty" value="<?php echo e($product->default_qty); ?>" class="form-control" min="1" style="text-align: center; font-weight: bold;" readonly>
      <span class="input-group-btn">
        <button id="qty-up" type="button" class="btn btn-info btn-flat"><i class="fa fa-plus"></i></button>
      </span>
    </div>                
  </div>
</div>



<script type="text/javascript">   
$(document).ready(function() {
    // to close the modal popup
    $('#close-modal').click(function () {
      $("#model-popup").modal('hide');
    });   

});  
</script><?php /**PATH D:\personal\lyly\papapos\resources\views/products/price.blade.php ENDPATH**/ ?>