<div class="pagination pagination-sm no-margin pull-right">
	{{ $data->links() }}
</div>
