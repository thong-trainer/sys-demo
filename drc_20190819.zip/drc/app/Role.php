<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    public static function list() {
    	return self::where('is_delete', 0)->where('is_hide', 0)->get();
    }
}
