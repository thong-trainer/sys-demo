<option value="0"><?php echo e(__('app.contact')); ?></option>
<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($item->id); ?>" <?php if($item->id == old('contact')): ?> selected <?php endif; ?>><?php echo e($item->contact_name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\personal\lyly\drc\resources\views/contacts/select.blade.php ENDPATH**/ ?>