<div class="row">
	<div class="col-md-12">
	  <!-- Custom Tabs -->
	  <div class="nav-tabs-custom">
	    <ul class="nav nav-tabs">
	    	<?php $__currentLoopData = $dimension_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    		<li class="<?php echo e($key == 0 ? 'active' : ''); ?>"><a href="#<?php echo e($key); ?>" data-toggle="tab"><?php echo e($detail->dimension->dimension_name); ?></a></li>
	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	     
	    </ul>
	    <div class="tab-content">
	    	<?php $__currentLoopData = $dimension_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		    	<div class="tab-pane <?php echo e($key == 0 ? 'active' : ''); ?>" id="<?php echo e($key); ?>">
              <table class="table table-bordered table-striped table-hover">
                <thead>
                  <tr>
                    <th><?php echo e(__('app.attribute')); ?></th>
                    <th style="width: 40px"><?php echo e(__('app.action')); ?></th>
                  </tr>
                </thead>
                <tbody>
                	<tr>
                		<td>
                			<input type="text" name="attribute">
                		</td>
                		<td>
                			<a href="#" title="Remove"><i class="fa fa-trash text-danger"></i></a>
                		</td>
                	</tr>
                </tbody>                
              </table>
			    </div>
	    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	   


	      <!-- /.tab-pane -->
	    </div>
	    <!-- /.tab-content -->
	  </div>
	  <!-- nav-tabs-custom -->
	</div>
	<!-- /.col -->	
</div><?php /**PATH D:\personal\lyly\papapos\resources\views/products/dimension.blade.php ENDPATH**/ ?>