<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Invoice</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/AdminLTE.min.css')); ?>">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<!-- <body id="content" > -->
<body onload="window.print();">
<?php
$company = Auth::user()->companyInfo();
$currency = $item->currency;
?>

<div class="wrapper">
  <!-- Main content -->
<section class="invoice">  
  <div class="row">  
      <div class="col-md-9">
        <div style="float: left;">
          <img src="<?php echo e(url($company->image_url)); ?>" style="width: 70px; height: 70px"/>
        </div>
        <div style="float: left;">
          &nbsp;&nbsp;&nbsp;<b style="font-size: 20px"><?php echo e($company->company_name); ?></b> <br> 
          &nbsp;&nbsp;&nbsp;<small style="font-size: 14px"><?php echo e($company->address); ?></small> <br> 
          &nbsp;&nbsp;&nbsp;<small style="font-size: 14px"><?php echo e(__('app.phone')); ?>: <?php echo e($company->telephone); ?> | <?php echo e(__('app.email')); ?>: <?php echo e($company->email ?: 'N/A'); ?></small>
        </div>
      </div>
      <div class="col-md-3">
         <small class="pull-right"><?php echo e(__('app.date')); ?>: <?php echo e($item->quotation_date); ?></small>
      </div>            
    </div> 
    <hr style="margin-top: 10px; margin-bottom: 10px">
  <!-- info row -->
  <div class="row invoice-info">
<!--     <div class="col-sm-4 invoice-col">
      <?php echo e(__('app.from')); ?>

      <address>
        <strong><?php echo e($company->company_name); ?></strong><br>
        <?php echo e($company->address); ?><br>
        <?php echo e(__('app.phone')); ?>: <?php echo e($company->telephone); ?><br>
        <?php echo e(__('app.email')); ?>: <?php echo e($company->email); ?>

      </address>
    </div> -->
    <!-- /.col -->
    <div class="col-sm-8 invoice-col">
        <address>
          <strong><?php echo e(__('app.customer_name')); ?>: <?php echo e($item->customer->contact->contact_name); ?></strong><br>
          <strong><?php echo e(__('app.address')); ?>: </strong> <?php echo e($item->customer->contact->main_address ?: 'N/A'); ?><br>
          <strong><?php echo e(__('app.phone')); ?>:</strong> <?php echo e($item->customer->contact->primary_telephone); ?><br>
          <strong><?php echo e(__('app.email')); ?>:</strong> <?php echo e($item->customer->contact->email ?: 'N/A'); ?>

        </address>
    </div>
    <!-- /.col -->
    <div class="col-sm-4 invoice-col pull-right">
      <!-- <b>Invoice: #12022</b><br> -->
      <br>
      <b><?php echo e(__('app.invoice_no')); ?>:</b> <?php echo e($item->invoice_number); ?><br>
      <b><?php echo e(__('app.due_date')); ?>:</b> <?php echo e($item->due_date); ?><br>
      <b><?php echo e(__('app.account_no')); ?>:</b> <?php echo e($item->customer->code); ?>

    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->

  <!-- Table row -->
  <div class="row">
    <div class="col-xs-12 table-responsive">
      <table class="table table-striped">
        <thead>
        <tr>
          <th>#</th>
          <th><?php echo e(__('app.description')); ?></th>
          <th><?php echo e(__('app.price')); ?></th>
          <th><?php echo e(__('app.qty')); ?></th>
          <th><?php echo e(__('app.tax')); ?></th>
          <th><?php echo e(__('app.subtotal')); ?></th>
        </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><?php echo e(\Auth::user()->splitDimension($detail->product_name)); ?> <?php echo \Auth::user()->dimensions($detail->variant_ids); ?> <?php echo $detail->notes ? '<br><em>'.$detail->notes.'</em>' : ''; ?> </td>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($detail->unit_price, $item)); ?></td>
            <td><?php echo e($detail->qty); ?></td>
            <td><?php echo e($detail->tax); ?>%</td>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($detail->subtotal, $item)); ?></td>
          </tr>            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </tbody>
      </table>
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->

  <div class="row">
    <!-- accepted payments column -->
    <div class="col-xs-6">

    </div>
    <!-- /.col -->
  
    <div class="col-xs-6">
      <div class="table-responsive">
        <table class="table">
          <tr>
            <th style="width:50%"><?php echo e(__('app.subtotal')); ?>:</th>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->amount, $item)); ?></td>
          </tr>
          <tr>
            <th><?php echo e(__('app.tax')); ?>:</th>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->tax, $item)); ?></td>
          </tr>
          <tr>
            <th><?php echo e(__('app.discount')); ?>:</th>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->discount_amount, $item)); ?></td>
          </tr>
          <tr>
            <th style="font-size: 18px"><?php echo e(__('app.grand_total')); ?>:</th>
            <td style="font-size: 20px; font-weight: bold"><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->grand_total, $item)); ?></td>
          </tr>
          <tbody>
            <?php $__currentLoopData = $item->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <em> <?php echo e(__('app.paid_on')); ?> <?php echo e($payment->payment_date); ?> </em></td>
              <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($payment->amount, $item)); ?> (<?php echo e($payment->payment_method); ?>)</td>
            </tr>            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tr>
            <th style="font-size: 18px"><?php echo e(__('app.amount_due')); ?>:</th>
            <td style="font-size: 20px; font-weight: bold"><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->grand_total - $item->payments->sum('amount'), $item)); ?></td>
          </tr>          
        </table>
      </div>
    </div>
    <!-- /.col -->
  </div>

  <!-- this row will not appear when printing -->
</section> 
  <!-- /.content -->
</div>
<script src="<?php echo e(asset('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<script type="text/javascript">
  
</script>
<!-- ./wrapper -->
</body>
</html>
<?php /**PATH D:\personal\lyly\drc\resources\views/invoices/print.blade.php ENDPATH**/ ?>