<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$company = Auth::user()->companyInfo();
$currency = $item->currency;
$default_currency = Auth::user()->defaultCurrency();
?>

<section class="content-header no-print">
  <h1>
    <?php echo e(__('app.invoice')); ?>

    <small>#<?php echo e($item->invoice_number); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('invoice.index')); ?>"><?php echo e(__('title.invoices')); ?></a></li>
    <li class="active"><?php echo e(__('title.show')); ?></li>
  </ol>
</section>
  <div class="modal fade" id="modal-payment" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div>
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h4 class="modal-title"><i class="fa fa-credit-card"></i> <?php echo e(__('title.submit_payment')); ?> </h4>
          </div>
          <form role="form" action="<?php echo e(route('invoice.update', $item->id)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>            
            <div class="modal-body">
              <div class="form-group">
                <label for="amount"><?php echo e(__('app.payment_amount')); ?> <span class="required">*</span></label>               
                <div class="input-group">
                  <span class="input-group-addon"><b><?php echo e($default_currency->symbol); ?></b></span>
                  <input type="number" step="any" id="amount" name="amount" class="form-control" min="0" value="<?php echo e($item->grand_total - $item->payments->sum('amount')); ?>" max="<?php echo e($item->grand_total - $item->payments->sum('amount')); ?>" required>
                </div>
                <p class="text-yellow "><i class="fa fa-info-circle"></i> <?php echo e(__('message.payment_note')); ?> (<?php echo e($default_currency->currency); ?>) </p>
              </div>
              <div class="row">
                <div class="col-md-6"> 
                  <div class="form-group">
                    <label for="payment-date"><?php echo e(__('app.payment_date')); ?>  <span class="required">*</span></label>
                    <div class="input-group date">
                      <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                      </div>
                      <input id="payment-date" type="date" class="form-control datepicker" name="payment_date" required>
                    </div> 
                  </div> 
                </div>
                <div class="col-md-6"> 
                  <div class="form-group">
                    <label for="payment-method"><?php echo e(__('app.payment_amount')); ?></label>
                    <select class="form-control" id="payment-method" name="payment_method">              
                      <option value="Cash" ><?php echo e(__('app.cash')); ?></option>
                      <option value="Bank" ><?php echo e(__('app.bank')); ?></option>
                    </select>  
                  </div>                   
                </div>
              </div>  

              <div class="form-group">
                <label for="name"><?php echo e(__('app.notes')); ?> </label>
                <textarea class="form-control" name="notes"></textarea>
              </div>                      
            </div>                   
            <div class="modal-footer">         
              <button type="submit" class="btn btn-primary"><?php echo e(__('title.submit')); ?></button>
              <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>  

  <div class="row">
    <div class="col-sm-12">      
        <?php if(Auth::user()->allowEdit(config('global.modules.invoice'))): ?>
          <?php if($item->status != config('global.invoice_status.paid')): ?>
          <a href="#modal-payment"  data-toggle="modal" class="btn btn-success"><i class="fa fa-credit-card"></i>&nbsp; <?php echo e(__('title.submit_payment')); ?></a>
          <?php endif; ?>
        <?php endif; ?>       
        &nbsp;
        <?php if(Auth::user()->allowExport(config('global.modules.invoice'))): ?>
          <a href="<?php echo e(route('invoice.print', $item->id)); ?>" class="btn btn-default"><i class="fa fa-print" title="Print/Saved PDF"></i>&nbsp; <?php echo e(__('title.print')); ?></a>
        <?php endif; ?> 
    </div>
  </div>  

<section class="invoice" style="margin: 10px 0px;">  
  <div class="row">
    <div class="col-xs-12">
      <h2 class="page-header">
        <img src="<?php echo e(url($company->image_url)); ?>" style="width: 50px; height: 50px"/>&nbsp;<b><?php echo e($company->company_name); ?></b>
        <small class="pull-right"><?php echo e(__('app.date')); ?>: <?php echo e($item->issue_date); ?></small>
      </h2>
    </div>
    <!-- /.col -->
  </div>
  <!-- info row -->
  <div class="row invoice-info">
    <div class="col-sm-4 invoice-col">
      <?php echo e(__('app.from')); ?>

      <address>
        <strong><?php echo e($company->company_name); ?></strong><br>
        <?php echo e($company->address); ?><br>
        <?php echo e(__('app.phone')); ?>: <?php echo e($company->telephone); ?><br>
        <?php echo e(__('app.email')); ?>: <?php echo e($company->email); ?>

      </address>
    </div>
    <!-- /.col -->
    <div class="col-sm-4 invoice-col">
      <?php echo e(__('app.to')); ?>

      <address>
        <strong><?php echo e($item->customer->contact->contact_name); ?></strong><br>
        <?php echo e($item->customer->contact->main_address ?: 'N/A'); ?><br>
        Phone: <?php echo e($item->customer->contact->primary_telephone); ?><br>
        Email: <?php echo e($item->customer->contact->email ?: 'N/A'); ?>

      </address>
    </div>
    <!-- /.col -->
    <div class="col-sm-4 invoice-col">
      <!-- <b>Invoice: #12022</b><br> -->
      <br>
      <b><?php echo e(__('app.invoice_no')); ?>:</b> <?php echo e($item->invoice_number); ?><br>
      <b><?php echo e(__('app.due_date')); ?>:</b> <?php echo e($item->due_date); ?><br>
      <b><?php echo e(__('app.account_no')); ?>:</b> <?php echo e($item->customer->code); ?>

    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->

  <!-- Table row -->
  <div class="row">
    <div class="col-xs-12 table-responsive">
      <table class="table table-striped">
        <thead>
        <tr>
          <th>#</th>
          <th><?php echo e(__('app.description')); ?></th>
          <th><?php echo e(__('app.price')); ?></th>
          <th><?php echo e(__('app.qty')); ?></th>
          <th><?php echo e(__('app.tax')); ?></th>
          <th><?php echo e(__('app.subtotal')); ?></th>
        </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><?php echo e($detail->product_name); ?> <br> <?php echo e($detail->notes); ?></td>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($detail->unit_price, $item)); ?></td>
            <td><?php echo e($detail->qty); ?></td>
            <td><?php echo e($detail->tax); ?>%</td>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($detail->subtotal, $item)); ?></td>
          </tr>            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
        </tbody>
      </table>
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->

  <div class="row">
    <!-- accepted payments column -->
    <div class="col-md-6 col-sm-6 col-xs-12">

    </div>
    <!-- /.col -->
    <div class="col-md-2 scol-sm-2 col-xs-12">
    </div>
    <div class="col-md-4 col-sm-4 col-xs-12">
      <div class="table-responsive">
        <table class="table">
          <tr>
            <th style="width:50%"><?php echo e(__('app.subtotal')); ?>:</th>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->amount, $item)); ?></td>
          </tr>
          <tr>
            <th><?php echo e(__('app.tax')); ?>:</th>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->tax, $item)); ?></td>
          </tr>
          <tr>
            <th><?php echo e(__('app.discount')); ?>:</th>
            <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->discount_amount, $item)); ?></td>
          </tr>
          <tr>
            <th style="font-size: 18px"><?php echo e(__('app.grand_total')); ?>:</th>
            <td style="font-size: 20px; font-weight: bold"><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->grand_total, $item)); ?></td>
          </tr>
          <tbody>
            <?php $__currentLoopData = $item->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td> <em> <?php echo e(__('app.paid_on')); ?> <?php echo e($payment->payment_date); ?> </em></td>
              <td><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($payment->amount, $item)); ?> (<?php echo e($payment->payment_method); ?>)</td>
            </tr>            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
          <tr>
            <th style="font-size: 18px"><?php echo e(__('app.amount_due')); ?>:</th>
            <td style="font-size: 20px; font-weight: bold"><?php echo e($currency->symbol); ?> <?php echo e(\Auth::user()->currencyFomart($item->grand_total - $item->payments->sum('amount'), $item)); ?></td>
          </tr>          
        </table>
      </div>
    </div>
    <!-- /.col -->
  </div>

  <!-- this row will not appear when printing -->
</section>  
</section>


    <!-- /.content -->
<!-- <div class="clearfix"></div> -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">   

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\drc\resources\views/invoices/show.blade.php ENDPATH**/ ?>