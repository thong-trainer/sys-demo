
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
  <td>                              
    <?php echo e($item['product_name']); ?> <a href="#" title="View Detail"><i class="fa fa-external-link"></i></a>
    <input type="hidden" name="product_id_array[]" value="<?php echo e($item['product_id']); ?>">
    <input type="hidden" name="product_name_array[]" value="<?php echo e($item['product_name']); ?>">
    <input type="hidden" name="variant_ids[]" value="<?php echo e($item['variant_ids']); ?>">    
    <input type="hidden" name="current_currency_id" value="<?php echo e($currency->id); ?>">
    <input id="current-currency-digit" type="hidden" name="current_currency_digit" value="<?php echo e($currency->digit); ?>">
    <input id="current-currency-symbol" type="hidden" name="current_currency_symbol" value="<?php echo e($currency->symbol); ?>">
  </td>
  <td>
    <?php echo e($currency->symbol); ?> <?php echo e(number_format($item['price'], $currency->digit)); ?>

    <input type="hidden" name="price_array[]" value="<?php echo e($item['price']); ?>">
  </td>
  <td>
    <input style="width: 70px" type="number" name="qty_array[]" min="1" value="<?php echo e($item['qty']); ?>" class="qty" >
  </td>
  <td>
    <span class="badge bg-default"><?php echo e($item['tax']); ?>%</span>
    <input type="hidden" name="tax_array[]" value="<?php echo e($item['tax']); ?>">
    <input type="hidden" name="pay_tax_array[]" value="<?php echo e($item['pay_tax']); ?>" class="tax">
    <input type="hidden" name="discount_array[]" value="<?php echo e($item['discount']); ?>">
    <input type="hidden" name="discount_amount_array[]" value="<?php echo e($item['discount_amount']); ?>" class="discount">
  </td>                  
  <td>
    <?php echo e($currency->symbol); ?> <?php echo e(number_format($item['subtotal'], $currency->digit)); ?>

    <input type="hidden" name="subtotal_array[]" value="<?php echo e($item['subtotal']); ?>" class="subtotal">
  </td>
  <td>
    <a href="#" title="Remove" class="remove"><i class="fa fa-trash text-danger"></i></a>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\personal\lyly\testing\drc\resources\views/quotations/generate-row.blade.php ENDPATH**/ ?>