<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.dashboard')); ?>

    <small><?php echo e(__('title.list_roles')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li class="active"><?php echo e(__('title.roles')); ?></li>
  </ol>
</section>
<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>    
  <div class="row">
    <div class="col-lg-12 col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(__('title.list_roles')); ?></h3>
              <!-- tools box - add new record-->
              <?php if(Auth::user()->allowCreate(config('global.modules.role'))): ?>
              <div class="pull-right box-tools">
                <a href="<?php echo e(route('role.create')); ?>" class="btn btn-primary btn-sm" data-widget="add-new" data-toggle="tooltip"
                        title="Add New"><i class="fa fa-plus"></i> <?php echo e(__('title.add_new')); ?></a>
              </div>
              <?php endif; ?>
              <!-- /. tools -->                            
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <!-- form search -->
              <!-- end form search -->
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th style="width: 10px">#</th>
                    <th><?php echo e(__('app.role')); ?></th>
                    <th><?php echo e(__('app.description')); ?></th>
                    <th style="width: 40px"><?php echo e(__('app.action')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($key+1); ?> </td>
                    <td><?php echo e($item->role_name); ?></td>
                    <td><?php echo e($item->description); ?></td>
                    <td>
                      <?php if(Auth::user()->allowEdit(config('global.modules.role'))): ?>
                      <a href="<?php echo e(route('role.edit', $item->id)); ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                      <?php endif; ?>                      
                      <?php if(Auth::user()->allowDelete(config('global.modules.role'))): ?>                      
                      <span style="padding: 5px">|</span><a href="#modelDelete_<?php echo e($item->id); ?>" data-toggle="modal" title="Remove"><i class="fa fa-trash text-danger"></i></a>
                      <div class="modal fade" id="modelDelete_<?php echo e($item->id); ?>" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                              <h4 class="modal-title"><?php echo e(__('title.delete')); ?> - <?php echo e($item->role_name); ?></h4>
                            </div>
                            <div class="modal-body">
                            <?php echo e(__('message.delete_confirmation')); ?>

                            <p class="margin"><i class="fa fa-warning"></i> <?php echo app('translator')->getFromJson('message.delete_warning'); ?> </p>
                            </div>
                            <div class="modal-footer">
                              <form action="<?php echo e(route('role.delete', $item->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete">
                                <button type="submit" class="btn btn-danger save-cancel"><?php echo e(__('title.yes_delete')); ?></button>
                                <button type="button" class="btn btn-default save-cancel" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                      <?php endif; ?>
                    </td>
                  </tr>                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>                
              </table>
            </div>
          </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\drc\resources\views/setups/roles/index.blade.php ENDPATH**/ ?>