<div class="pagination pagination-sm no-margin pull-right">
	<?php echo e($data->links()); ?>

</div>
<?php /**PATH D:\personal\lyly\drc\resources\views/layouts/pagination.blade.php ENDPATH**/ ?>