
<?php $__env->startSection('css'); ?>
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.dashboard')); ?>

    <small><?php echo e(__('title.list_customers')); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li class="active"><?php echo e(__('title.customers')); ?></li>
  </ol>
</section>
<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>    
  <div class="row">
    <div class="col-lg-12 col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(__('title.list_customers')); ?></h3>
              <!-- tools box - add new record-->
              <?php if(Auth::user()->allowCreate(config('global.modules.customer'))): ?>
              <div class="pull-right box-tools">
                <a href="<?php echo e(route('customer.create', ['type'=>'individual'])); ?>" class="btn btn-primary btn-sm" data-widget="add-new" data-toggle="tooltip"
                        title="Add New"><i class="fa fa-plus"></i> <?php echo e(__('title.add_new')); ?></a>
              </div>
              <?php endif; ?>
              <!-- /. tools -->              
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <!-- form search -->
              <form action="<?php echo e(route('customer.index')); ?>" method="GET">
                <div class="m-container">
                  <div class="m-left">           
                    <div class="input-group" style="float: left">                                            
                      <select class="form-control" name="group">
                        <option value=""><?php echo e(__('app.customer_group')); ?></option>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if(Request::get('group') == $item->id): ?> selected <?php endif; ?>><?php echo e($item->group_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>     
                    <div class="input-group" style="float: left;">
                      <button type="submit" class="btn btn-default"><i class="fa fa-filter"></i> <?php echo e(__('title.filter')); ?></button>
                    </div>
                  </div>
                  <div class="m-right">
                    <div class="input-group input-group pull-right" style="width: 300px;">
                      <input type="text" name="search" value="<?php echo e(Request::get('search')?:''); ?>" class="form-control" placeholder="<?php echo e(__('title.search')); ?>">
                      <span class="input-group-btn">
                        <button type="submit" class="btn btn-info btn-flat"><i class="fa fa-search"></i></button>
                        <a href="<?php echo e(route('customer.index')); ?>" class="btn btn-danger btn-flat"><i class="fa fa-refresh"></i></a>
                      </span>
                    </div>                    
                  </div>
                  <div id="center"></div>
                </div>
              </form>
              <!-- end form search -->
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <!-- <th style="width: 10px">#</th> -->
                    <th><?php echo e(__('app.code')); ?></th>
                    <th><?php echo e(__('app.customer_name')); ?></th>
                    <th><?php echo e(__('app.gender')); ?></th>
                    <th><?php echo e(__('app.primary_telephone')); ?></th>
                    <th><?php echo e(__('app.customer_group')); ?></th>
                    <th><?php echo e(__('app.company')); ?></th>
                    <th style="width: 40px"><?php echo e(__('app.action')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <!-- <td><?php echo e($key+1); ?> </td> -->
                    <td><?php echo e($item->code); ?> </td>
                    <td><?php echo e($item->contact->contact_name); ?></td>
                    <td><?php echo e($item->contact->gender); ?></td>
                    <td><?php echo e($item->contact->primary_telephone); ?></td>
                    <td><a href="<?php echo e(route('customer-group.show', $item->group_id)); ?>/show" title="<?php echo e($item->group->description); ?>"><?php echo e($item->group->group_name); ?> <i class="fa fa-external-link"></i></a></td>
                    <td>
                      <?php if($item->company): ?>
                        <a href="<?php echo e(route('company.show', $item->company_id)); ?>" title="View Detail"><?php echo e($item->company->company_name); ?> <i class="fa fa-external-link"></i></a>
                      <?php else: ?>
                        <a href="#" title="Nothing">N/A</a>
                      <?php endif; ?>                      
                    </td>                    
                    <td>
                      <?php if(Auth::user()->allowEdit(config('global.modules.customer'))): ?>
                      <a href="<?php echo e(route('customer.edit', $item->id)); ?>" title="Edit"><i class="fa fa-pencil"></i></a>
                      <?php endif; ?>

                      <?php if(Auth::user()->allowDelete(config('global.modules.customer'))): ?>
                      <span style="padding: 5px">|</span><a href="#modelDelete_<?php echo e($item->id); ?>" data-toggle="modal" title="Remove"><i class="fa fa-trash text-danger"></i></a>
                      <div class="modal fade" id="modelDelete_<?php echo e($item->id); ?>" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                              <h4 class="modal-title"><?php echo e(__('title.delete')); ?> - <?php echo e($item->contact->contact_name); ?></h4>
                            </div>
                            <div class="modal-body">
                            <?php echo e(__('message.delete_confirmation')); ?>

                            </div>
                            <div class="modal-footer">
                              <form action="<?php echo e(route('customer.delete', $item->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="_method" value="delete">
                                <button type="submit" class="btn btn-danger save-cancel"><?php echo e(__('title.delete')); ?></button>
                                <button type="button" class="btn btn-default save-cancel" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                      <?php endif; ?>
                    </td>
                  </tr>                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>                
              </table>
            </div>
            <div class="box-footer clearfix">
              <?php echo $__env->make('layouts.pagination', ['data'=>$customers], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>            
          </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/leykamthong/Desktop/projects/selingmix.com/drc/resources/views/customers/index.blade.php ENDPATH**/ ?>