<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.settings')); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li class="active"><?php echo e(__('title.settings')); ?></li>
  </ol>
</section>

<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>  
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(__('title.company_information')); ?></h3>            
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="<?php echo e(route('setting.update', $company->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-8 col-sm-12">
                <div class="form-group <?php if ($errors->has('role_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role_name'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="description"><?php echo e(__('app.company_name')); ?> <span class="required">*</span></label>
                  <input type="text" class="form-control" id="company_name" name="company_name" value="<?php echo e(old('company_name') ?: $company->company_name); ?>" required>
                  <?php if ($errors->has('role_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('role_name'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>
                <div class="form-group <?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="type"><?php echo e(__('app.type')); ?> <span class="required">*</span></label>
                  <input type="text" class="form-control" id="type" name="type" value="<?php echo e(old('type') ?: $company->type); ?>" required>
                  <?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>       
                <div class="form-group <?php if ($errors->has('telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telephone'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="telephone"><?php echo e(__('app.telephone')); ?> <span class="required">*</span></label>
                  <input type="text" class="form-control" id="telephone" name="telephone" value="<?php echo e(old('telephone') ?: $company->telephone); ?>" required>
                  <?php if ($errors->has('telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('telephone'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>     
                <div class="form-group <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="email"><?php echo e(__('app.email')); ?> <span class="required">*</span></label>
                  <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email') ?: $company->email); ?>" required>
                  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>     
                <div class="form-group <?php if ($errors->has('website')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('website'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="website"><?php echo e(__('app.website')); ?> <span class="required">*</span></label>
                  <input type="text" class="form-control" id="website" name="website" value="<?php echo e(old('website') ?: $company->website); ?>" required>
                  <?php if ($errors->has('website')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('website'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>                                                                   
                <div class="form-group <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="address"><?php echo e(__('app.address')); ?> <span class="required">*</span></label>
                  <textarea type="text" rows="5" class="form-control" id="address" name="address" required><?php echo e(old('address') ?: $company->address); ?></textarea>
                  <?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>                 
                <div class="form-group <?php if ($errors->has('notes')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('notes'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="notes"><?php echo e(__('app.notes')); ?> <span class="required">*</span></label>
                  <textarea type="text" rows="5" class="form-control" id="notes" name="notes" required><?php echo e(old('notes') ?: $company->notes); ?></textarea>
                  <?php if ($errors->has('notes')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('notes'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>                                  
              </div>                

              <div class="col-lg-6 col-md-4 col-sm-12">
                <div class="form-group">
                  <img class="img-upload" id="blah" src="<?php echo e(url($company->image_url)); ?>" alt="your image" />
                  <input type='file' id="imgInp" name="file_upload" class="hide-file-name" />
                  <input class="btn-upload" type="button" value="Browse" onclick="document.getElementById('imgInp').click();"/>
                </div>
              </div>                  
            </div>

          </div>

          <div class="box-footer">
            <a href="<?php echo e(route('role.index')); ?>" class="btn btn-default"><?php echo e(__('title.cancel')); ?></a>&nbsp;&nbsp;&nbsp;
            <?php if(Auth::user()->allowEdit(config('global.modules.setting'))): ?>
            <button type="submit" class="btn btn-primary"><?php echo e(__('title.save_changes')); ?></button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">   
  function readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
          $('#blah').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  $("#imgInp").change(function(){
    readURL(this);
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\papapos\resources\views/setups/settings/index.blade.php ENDPATH**/ ?>