<tr>
  <td>
    <?php echo e($product->product_name); ?> <a href="#" title="View Detail"><i class="fa fa-external-link"></i></a>
    <input type="hidden" name="product_id_array[]" value="<?php echo e($product->id); ?>">
  </td>
  <td>
    <input style="width: 70px" type="number" name="initial_qty_array[]" value="<?php echo e($qty); ?>">
  </td>
  <td><?php echo e($product->saleUnit->unit_name); ?></td>      
  <td>
    <a href="#" title="Remove" class="remove"><i class="fa fa-trash text-danger"></i></a>
  </td>    
</tr> <?php /**PATH /Users/leykamthong/Desktop/projects/selingmix.com/drc/resources/views/stocks/row.blade.php ENDPATH**/ ?>