<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.extra_prices')); ?>

    <small>#<?php echo e($product->barcode); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('product.show', $product->id)); ?>/show"><?php echo e($product->barcode); ?></a></li>
    <li class="active"><?php echo e(__('title.extra_prices')); ?></li>
  </ol>
</section>
<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>   

  <?php 
  $currency = Auth::user()->defaultCurrency()
  ?> 
  <div class="row">
    <div class="col-lg-12 col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e($product->product_name); ?></h3>
              <!-- tools box - add new record-->
              <!-- /. tools -->                            
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <!-- form search -->
              <!-- end form search -->
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th style="width: 10px">#</th>
                    <th style="width: 250px"><?php echo e(__('app.dimension')); ?></th>                    
                    <th><?php echo e(__('app.value')); ?></th>
                    <th><?php echo e(__('app.extra_price')); ?></th>
                    <th style="width: 40px"><?php echo e(__('app.action')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($key+1); ?> </td>
                    <td><?php echo e($item->dimension->dimension_name); ?></td>
                    <td><?php echo e($item->value); ?></td>
                    <td><span class="label label-success"><?php echo e($currency->symbol); ?> <?php echo e(number_format($item->extra_price, $currency->digit)); ?></span>  </td>
                    <td>
                      <?php if(Auth::user()->allowEdit(config('global.modules.product_price'))): ?>
                      <a href="#modelUpdate_<?php echo e($item->id); ?>" data-toggle="modal" title="Edit"><i class="fa fa-pencil"></i></a>
                      <div class="modal fade" id="modelUpdate_<?php echo e($item->id); ?>" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                        <div class="modal-dialog">
                          <form action="<?php echo e(route('variant.update', $item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>                                
                            <div class="modal-content">
                              <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                <h4 class="modal-title"><?php echo e(__('title.extra_price')); ?> - <?php echo e($item->dimension->dimension_name); ?> (<?php echo e($item->value); ?>)</h4>
                              </div>
                              <div class="modal-body">
                                <div class="input-group">
                                  <span class="input-group-addon"><b><?php echo e($currency->symbol); ?></b></span>
                                  <input type="number" step="any" id="price" name="price" class="form-control" min="0" value="<?php echo e($item->extra_price); ?>" required>
                                </div> 
                              </div>
                              <div class="modal-footer">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('title.save_changes')); ?></button>
                                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>                              
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                      <?php endif; ?>                                            
                    </td>
                  </tr>                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>                
              </table>
            </div>
          </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\papapos\resources\views/product-prices/extra-price.blade.php ENDPATH**/ ?>