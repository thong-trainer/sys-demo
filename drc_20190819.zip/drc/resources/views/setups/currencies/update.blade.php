@extends('layouts.master')
@section('css')
<style type="text/css">
  
</style>
@endsection
@section('content')
<section class="content-header">
  <h1>
    {{ __('title.edit_currency') }} <small>#{{ $item->id }}</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="{{ route('dashboard') }}"><i class="fa fa-dashboard"></i>{{ __('title.dashboard') }}</a></li>
    <li><a href="{{ route('currency.index') }}">{{ __('title.currencies') }}</a></li>
    <li class="active">{{ __('title.edit') }}</li>
  </ol>
</section>

<section class="content">
  @if(session()->has('message'))      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> {{ __('message.success') }}</h4>
      {{ session()->get('message') }}
    </div>      
  @endif  


  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> {{ __('title.currency_information') }}</h3>            
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="{{ route('currency.update', $item->id) }}" method="POST">
            @csrf @method('PUT')
            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-8 col-sm-12">

                <div class="form-group @error('currency') has-error @enderror">
                  <label for="currency">{{ __('app.currency') }} <span class="required">*</span></label>
                  <input type="text" class="form-control" id="currency" name="currency" value="{{ old('currency')?:$item->currency }}" required>
                  @error('currency')
                    <span class="help-block">{{ $message }}</span>
                  @enderror                      
                </div>
                <div class="row">
                  <div class="col-md-6 form-group @error('symbol') has-error @enderror">
                    <label for="symbol">{{ __('app.symbol') }} <span class="required">*</span></label>
                    <input type="text" class="form-control" id="symbol" name="symbol" value="{{ old('symbol')?:$item->symbol }}" placeholder="$" required>
                    @error('symbol')
                      <span class="help-block">{{ $message }}</span>
                    @enderror                      
                  </div>       
                  
                  <div class="col-md-6 form-group">
                    <label for="symbol">{{ __('app.digit') }} <span class="required">*</span></label>
                    <input type="number" class="form-control" id="digit" name="digit" value="{{ old('digit')?:$item->digit}}" min="0" max="4" required>                  
                  </div> 
                </div>
                <div class="row">
                  <div class="col-md-6 form-group">
                    <label for="calculation">{{ __('app.calculation') }}</label>
                    <select class="form-control" name="calculation">
                      <option value="">N/A</option>
                      @foreach(config('global.currency_calculation') as $value)
                      <option value="{{ $value }}" @if($value == old('calculation')) selected @elseif($value == $item->calculation) selected @endif>{{ $value }}</option>
                      @endforeach
                    </select>   
                  </div>
                </div>


                <div class="form-group ">
                  <label for="description">{{ __('app.description') }} <span class="required">*</span></label>
                  <textarea type="text" rows="5" class="form-control" id="description" name="description">{{ old('description')?:$item->description }}</textarea>          
                </div>                                  
              </div>                

              <div class="col-lg-6 col-md-4 col-sm-12">
                <div class="box-body table-responsive no-padding">
                  <table class="table table-striped table-hover">
                    <thead>
                      <tr>
                        <th>{{ __('app.exchange_rate') }}</th>
                        <th>{{ __('app.applied_date') }}</th>
                        <th style="width: 40px">{{ __('app.action') }}</th>
                      </tr>
                    </thead>
                    <tbody>
                      @foreach($item->rates as $key => $rate)
                      <tr>
                        <td>{{ $rate->rate }}</td>
                        <td>{{ $rate->applied_date }}</td>
                        <td>
                          @if(Auth::user()->allowDelete(config('global.modules.currency')))                      
                          <a href="#modal-delete-{{$rate->id}}" data-toggle="modal" title="Remove"><i class="fa fa-trash text-danger"></i></a>
                          <div class="modal fade" id="modal-delete-{{$rate->id}}" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                  <h4 class="modal-title">{{ __('title.delete') }} - {{$rate->rate}}</h4>
                                </div>
                                <div class="modal-body">
                                {{ __('message.delete_confirmation') }}
                                <p class="margin"><i class="fa fa-warning"></i> @lang('message.delete_warning') </p>
                                </div>
                                <div class="modal-footer">
                                  <form action="{{ route('currency.exchange.rate.delete', $rate->id) }}" method="POST">
                                    @csrf
                                    <input type="hidden" name="_method" value="delete">
                                    <button type="submit" class="btn btn-danger save-cancel">{{ __('title.yes_delete') }}</button>
                                    <button type="button" class="btn btn-default save-cancel" data-dismiss="modal">{{ __('title.cancel') }}</button>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>                          
                          @endif
                        </td>
                      </tr>                  
                      @endforeach
                      <tr>
                        <td colspan="3">
                          <a href="#modal-rate" data-toggle="modal" title="Add New"><i class="fa fa-plus text-primary new"></i> {{ __('title.add_new') }}</a>
                        </td>
                      </tr>                      
                    </tbody>                
                  </table>
                </div>                
              </div>                  
            </div>

          </div>

          <div class="box-footer">
            <a href="{{route('currency.index')}}" class="btn btn-default">{{ __('title.cancel') }}</a>&nbsp;&nbsp;&nbsp;
            @if(Auth::user()->allowEdit(config('global.modules.currency')))
            <button type="submit" class="btn btn-primary">{{ __('title.save_changes') }}</button>
            @endif
          </div>
        </form>
      </div>
      </div>      
    </div>
  </div>
</section>
  <div class="modal fade" id="modal-rate" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div id="product-form">
        <form role="form" action="{{ route('currency.exchange.rate.store') }}" method="POST">
          @csrf
          <input type="hidden" name="currency_id" value="{{ $item->id }}">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
              <h4 class="modal-title">{{ __('title.add_new') }} ({{ \Auth::user()->defaultCurrency()->currency }} <i class="fa fa-arrow-right"></i> {{ $item->currency }})</h4>
            </div>
            <div class="modal-body">
              <div class="form-group">
                <label for="rate">{{ __('app.exchange_rate') }} <span class="required">*</span></label>
                <input type="number" step="any" class="form-control" id="rate" name="rate" value="{{ old('rate')?: 0}}" min="0" required>                   
              </div>
            </div>                   
            <div class="modal-footer">         
              <button type="submit" class="btn btn-primary">{{ __('title.save') }}</button>
              <button type="button" class="btn btn-default" data-dismiss="modal">{{ __('title.cancel') }}</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
@endsection
@section('js')

<script type="text/javascript">   

</script>
@endsection