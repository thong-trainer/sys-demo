
<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.stock_on_hand')); ?>

    <small>#<?php echo e($product->barcode); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('product.show', $product->id)); ?>/show"><?php echo e($product->barcode); ?></a></li>
    <li class="active"><?php echo e(__('title.on_hand')); ?></li>
  </ol>
</section>
<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>    
  <div class="row">
    <div class="col-md-4 col-sm-12">
      <div class="small-box bg-aqua">
        <div class="inner">
          <h3><?php echo e($product->stockIn()); ?> <sup style="font-size: 20px">(<?php echo e($product->saleUnit->unit_name); ?>)</sup></h3>
          <p><?php echo e(__('title.total')); ?></p>
        </div>
        <div class="icon">
          <i class="ion ion-pie-graph"></i>
        </div>
      </div>
    </div>
    <div class="col-md-4 col-sm-12">
      <div class="small-box bg-green">
        <div class="inner">
          <h3><?php echo e($product->stockOut()); ?> <sup style="font-size: 20px">(<?php echo e($product->saleUnit->unit_name); ?>)</sup></h3>
          <p><?php echo e(__('title.stock_out')); ?></p>
        </div>
        <div class="icon">
          <i class="fa fa-shopping-cart"></i>
        </div>
      </div>
    </div>
    <div class="col-md-4 col-sm-12">
      <div class="small-box bg-red">
        <div class="inner">
          <h3><?php echo e($product->onHand()); ?> <sup style="font-size: 20px">(<?php echo e($product->saleUnit->unit_name); ?>)</sup></h3>
          <p><?php echo e(__('title.on_hand')); ?></p>
        </div>
        <div class="icon">
          <i class="ion ion-stats-bars"></i>
        </div>
      </div>
    </div>        
  </div>
  <div class="row">
    <div class="col-lg-12 col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo e(__('title.stock_transaction')); ?></h3>
              <!-- tools box - add new record-->              
              <!-- /. tools -->                            
            </div>
            <!-- /.box-header -->
            <div class="box-body table-responsive no-padding">
              <!-- form search -->
              <!-- end form search -->
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th style="width: 10px">#</th>
                    <th><?php echo e(__('app.product_name')); ?></th>
                    <th><?php echo e(__('app.location')); ?></th>
                    <th><?php echo e(__('app.quantity')); ?></th>
                    <th><?php echo e(__('app.movement_type')); ?></th>
                    <th style="width: 140px"><?php echo e(__('app.date')); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $is_stock_in = ($item->stockMovement->remark == config('global.stock_status.stock_in')) ? true : false
                  ?>
                  <tr style="<?php echo e($is_stock_in ? '' : 'color:red'); ?>">
                    <td><?php echo e($key+1); ?> </td>
                    <td><?php echo e($item->product->product_name); ?></td>
                    <td><?php echo e($item->stockMovement->location->location_name); ?></td>
                    <td><?php echo e($item->initial_qty); ?></td>
                    <td><?php echo e($item->stockMovement->movementType->movement_type); ?></td>
                    <td><?php echo e($item->created_at); ?></td>
                  </tr>                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>                
              </table>
            </div>
            <div class="box-footer clearfix">
              <?php echo $__env->make('layouts.pagination', ['data'=>$stocks], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>               
          </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/leykamthong/Desktop/projects/selingmix.com/drc/resources/views/stocks/show.blade.php ENDPATH**/ ?>