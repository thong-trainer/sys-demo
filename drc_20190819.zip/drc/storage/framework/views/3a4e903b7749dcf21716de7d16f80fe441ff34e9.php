<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.edit_supplier')); ?> <small>#<?php echo e($supplier->id); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('customer.index')); ?>"><?php echo e(__('title.suppliers')); ?></a></li>
    <li class="active"><?php echo e(__('title.edit')); ?></li>
  </ol>
</section>

<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>  
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(__('title.supplier_information')); ?></h3>            
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="<?php echo e(route('supplier.update', $supplier->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-8 col-sm-12">
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="form-group">
                      <img class="img-upload" id="blah" src="<?php echo e(url($supplier->contact->image_url)); ?>" alt="your image" />
                      <input type='file' id="imgInp" name="file_upload" class="hide-file-name" accept="image/png, image/jpeg"/>
                      <input class="btn-upload" type="button" value="Browse" onclick="document.getElementById('imgInp').click();" />
                    </div>                    
                  </div>
                  <div class="col-lg-8 col-md-8 col-sm-12">                    
                    <div class="form-group <?php if ($errors->has('contact_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact_name'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <label class="control-label"><i class="fa fa-check"></i> <?php echo e($supplier->type); ?></label>
                      <input type="text" class="form-control big-input" name="contact_name" value="<?php echo e(old('contact_name')?: $supplier->contact->contact_name); ?>" placeholder="<?php echo e(__('app.contact_name')); ?>" required>
                      <?php if ($errors->has('contact_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact_name'); ?>
                      <span class="help-block"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                    </div>
                    
                    <div class="form-group" style="width: 250px">                      
                      <select class="form-control select2" id="select-company" name="company">
                        <option value="0"><?php echo e(__('app.company')); ?></option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('company') || $supplier->company_id == $item->id): ?> selected <?php endif; ?> ><?php echo e($item->company_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>                                            
                    </div>            
                                        

                    <div class="form-group <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <label>
                        <input type="radio" value="male" name="gender" class="flat-red" <?php if($supplier->contact->gender == 'male'): ?> checked <?php endif; ?> >
                        <?php echo e(__('app.male')); ?>

                      </label>&nbsp;&nbsp;&nbsp;
                      <label>
                        <input type="radio" value="female" name="gender" class="flat-red" <?php if($supplier->contact->gender == 'female'): ?> checked <?php endif; ?> >
                        <?php echo e(__('app.female')); ?>

                      </label>
                    </div>                                   
                  </div>                    
                </div>
                <div class="form-group">
                  <label for="notes"><?php echo e(__('app.notes')); ?> </label>
                  <textarea type="text" rows="8" class="form-control" id="notes" name="notes"><?php echo e(old('note') ?: $supplier->contact->notes); ?></textarea>
                </div>                    
              </div>

              <div class="col-lg-6 col-md-4 col-sm-12">

                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <div class="form-group">
                      <label for="position"><?php echo e(__('app.position')); ?></label>
                      <input type="text" class="form-control" id="position" name="position" value="<?php echo e(old('position') ?: $supplier->contact->position); ?>">
                    </div>                                               
                  </div>
                </div> 

                <div class="form-group">
                  <label for="email"><?php echo e(__('app.email')); ?> </label>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                    <input type="email" id="email" name="email" class="form-control" placeholder="example@mail.com" value="<?php echo e(old('email') ?: $supplier->contact->email); ?>">
                  </div>                            
                </div>                                               
                <div class="form-group <?php if ($errors->has('primary_telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('primary_telephone'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="primary-telephone"><?php echo e(__('app.primary_telephone')); ?> <span class="required">*</span></label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-phone"></i>
                    </div>
                    <input type="text" class="form-control" id="primary-telephone" name="primary_telephone" value="<?php echo e(old('primary_telephone') ?: $supplier->contact->primary_telephone); ?>" data-inputmask='"mask": "(999) 999-9999"' data-mask>
                  </div>
                  <?php if ($errors->has('primary_telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('primary_telephone'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                   
                </div>
                <div class="form-group">
                  <label for="other-telephone"><?php echo e(__('app.other_telephone')); ?></label>
                  <input type="text" class="form-control" id="other-telephone" name="other_telephone" value="<?php echo e(old('other_telephone') ?: $supplier->contact->other_telephone); ?>">
                </div>         
              

                <div class="form-group">
                  <label for="address"><?php echo e(__('app.address')); ?> </label>
                  <textarea type="text" rows="2" class="form-control" id="address" name="address"><?php echo e(old('address') ?: $supplier->contact->main_address); ?></textarea>
                </div> 
                
              </div>
               
            </div>
          </div>

          <div class="box-footer">
            <a href="<?php echo e(route('supplier.index')); ?>" class="btn btn-default"><?php echo e(__('title.cancel')); ?></a>&nbsp;&nbsp;&nbsp;
            <?php if(Auth::user()->allowEdit(config('global.modules.supplier'))): ?>
            <button type="submit" class="btn btn-primary"><?php echo e(__('title.save_changes')); ?></button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">   
$(document).ready(function() {
  $('#radio-individual').on('ifChanged', function(e){
    if(e.target.checked == true) {
      $('#company-div').show();
    } else {
      $('#company-div').hide();
      $('#select-company').val(0).trigger('change');
    }
  });

  function readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
          $('#blah').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  $("#imgInp").change(function(){
    readURL(this);
  });    
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\drc\resources\views/suppliers/update.blade.php ENDPATH**/ ?>