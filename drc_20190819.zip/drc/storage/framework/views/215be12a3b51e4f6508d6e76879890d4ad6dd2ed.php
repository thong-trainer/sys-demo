<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.new_supplier')); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('supplier.index')); ?>"><?php echo e(__('title.suppliers')); ?></a></li>
    <li class="active"><?php echo e(__('title.create')); ?></li>
  </ol>
</section>

<?php if(!Request::get('type')): ?>
  <script>window.location = "/dashboard";</script>  
<?php endif; ?> 
  

<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>  
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(__('title.supplier_information')); ?></h3>            
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="<?php echo e(route('supplier.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="type" value="<?php echo e(Request::get('type')); ?>">
            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-8 col-sm-12">
                 
                <div class="row">
                  <div class="col-lg-4 col-md-4 col-sm-12">
                    <div class="form-group">
                      <img class="img-upload" id="blah" src="<?php echo e(url(config('global.paths.contact'))); ?>/contact-placeholder.jpg" alt="your image" />
                      <input type='file' id="imgInp" name="file_upload" class="hide-file-name" accept="image/png, image/jpeg"/>
                      <input class="btn-upload" type="button" value="Browse" onclick="document.getElementById('imgInp').click();" />
                    </div>                    
                  </div>
                  <div class="col-lg-8 col-md-8 col-sm-12">
                    <div id="#my-type" class="form-group <?php if ($errors->has('type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('type'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <label >
                        <input id="radio-individual" type="radio" value="individual" name="type" class="flat-red" <?php if(Request::get('type') == "individual"): ?> checked <?php endif; ?> >
                        <?php echo e(__('app.individual')); ?>

                      </label>&nbsp;&nbsp;&nbsp;
                      <label >
                        <input type="radio" value="company" name="type" class="flat-red" <?php if(Request::get('type') == "company"): ?> checked <?php endif; ?> >
                        <?php echo e(__('app.company')); ?>

                      </label>
                    </div>          
                    <!-- we use company_name for both individual and company -->
                    <div class="form-group <?php if ($errors->has('company_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company_name'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <input type="text" class="form-control big-input" id="name" name="company_name" value="<?php echo e(old('company_name')); ?>" placeholder="<?php echo e(__('app.name')); ?>" required>
                      <?php if ($errors->has('company_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('company_name'); ?>
                      <span class="help-block"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                    </div>

                    <?php if(Request::get('type') == "individual"): ?>
                    <div class="form-group" >
                      <select class="form-control select2 " id="select-company" name="company" style="width: 250px">
                        <option value="0"><?php echo e(__('app.company')); ?></option>
                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('company')): ?> selected <?php endif; ?>><?php echo e($item->company_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>
                    <div class="form-group <?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <label>
                        <input type="radio" value="male" name="gender" class="flat-red" <?php if(old('gender') == "male"): ?> checked <?php endif; ?> >
                        <?php echo e(__('app.male')); ?>

                      </label>&nbsp;&nbsp;&nbsp;
                      <label>
                        <input type="radio" value="female" name="gender" class="flat-red" <?php if(old('gender') == "female"): ?> checked <?php endif; ?> >
                        <?php echo e(__('app.female')); ?>

                      </label>
                    </div>                     
                    <?php else: ?>
                    <div class="form-group <?php if ($errors->has('contact')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                      <select class="form-control select2" id="select-contact" id="contact-select" name="contact" style="width: 200px;">
                        <option value="0"><?php echo e(__('app.contact')); ?></option>
                        <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>" <?php if($item->id == old('contact')): ?> selected <?php endif; ?>><?php echo e($item->contact_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>   
                      <?php if ($errors->has('contact')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('contact'); ?>
                      <span class="help-block"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                                         
                    </div> 
                    <?php endif; ?>                   
                                   
                  </div>                    
                </div>
                <div class="form-group">
                  <label for="note"><?php echo e(__('app.notes')); ?> </label>
                  <textarea type="text" rows="8" class="form-control" id="notes" name="note"><?php echo e(old('notes')); ?></textarea>
                </div>     
              </div>

              <div class="col-lg-6 col-md-4 col-sm-12">     
                <div class="row">
                  <div class="col-lg-6 col-md-6 col-sm-12">
                    <?php if(Request::get('type') == "individual"): ?>
                    <div class="form-group" id="position-div">
                      <label for="position"><?php echo e(__('app.position')); ?></label>
                      <input type="text" class="form-control" id="position" name="position" value="<?php echo e(old('position')); ?>">
                    </div> 
                    <?php else: ?>
                    <div class="form-group" id="website-div">
                      <label for="website"><?php echo e(__('app.website')); ?></label>
                      <input type="text" class="form-control" id="website" name="website" value="<?php echo e(old('website')); ?>">
                    </div>
                    <?php endif; ?>                                                                   
                  </div>
                </div> 

                <div class="form-group">
                  <label for="email"><?php echo e(__('app.email')); ?> </label>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                    <input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="example@mail.com">
                  </div>                            
                </div>    
                <?php if(Request::get('type') == "individual"): ?>               
                <div id="primary-telephone-div" class="form-group <?php if ($errors->has('primary_telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('primary_telephone'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="primary-telephone"><?php echo e(__('app.primary_telephone')); ?> <span class="required">*</span></label>
                  <div class="input-group">
                    <div class="input-group-addon">
                      <i class="fa fa-phone"></i>
                    </div>
                    <input type="text" class="form-control" id="primary-telephone" name="primary_telephone" value="<?php echo e(old('primary_telephone')); ?>" data-inputmask='"mask": "(999) 999-9999"' data-mask>
                  </div>
                  <?php if ($errors->has('primary_telephone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('primary_telephone'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                   
                </div>
                <?php endif; ?>  
                <div class="form-group">
                  <label for="other-telephone"><?php echo e(__('app.other_telephone')); ?></label>
                  <input type="text" class="form-control" id="other-telephone" name="other_telephone" value="<?php echo e(old('other_telephone')); ?>">
                </div>   

                <div class="form-group">
                  <label for="address"><?php echo e(__('app.address')); ?> </label>
                  <textarea type="text" rows="2" class="form-control" id="address" name="address"><?php echo e(old('address')); ?></textarea>
                </div>
              </div>           
            </div>
          </div>

          <div class="box-footer">
            <a href="<?php echo e(route('supplier.index')); ?>" class="btn btn-default"><?php echo e(__('title.cancel')); ?></a>&nbsp;&nbsp;&nbsp;
            <?php if(Auth::user()->allowCreate(config('global.modules.supplier'))): ?>
            <button type="submit" class="btn btn-primary"><?php echo e(__('title.save')); ?></button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">   
$(document).ready(function() {
  
  $('#radio-individual').on('ifChanged', function(e){
    var url   = window.location.href;
    arr = url.split('=');
    if(e.target.checked == true) {
      window.location.replace(arr[0] + '=individual');
    } else {
      window.location.replace(arr[0] + '=company');
    }
  });

  function readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
          $('#blah').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
    }
  }

  $("#imgInp").change(function(){
    readURL(this);
  });    
});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\testing\drc\resources\views/suppliers/create.blade.php ENDPATH**/ ?>