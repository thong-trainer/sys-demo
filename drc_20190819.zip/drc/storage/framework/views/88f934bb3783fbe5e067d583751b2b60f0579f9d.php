
<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.new_dimension')); ?>

  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('dimension.index')); ?>"><?php echo e(__('title.dimensions')); ?></a></li>
    <li class="active"><?php echo e(__('title.create')); ?></li>
  </ol>
</section>

<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>  
  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(__('title.dimension_information')); ?></h3>            
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="<?php echo e(route('dimension.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-8 col-sm-12">

                <div class="form-group <?php if ($errors->has('dimension_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dimension_name'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="role"><?php echo e(__('app.dimension_name')); ?> <span class="required">*</span></label>
                  <input type="text" class="form-control" id="role" name="dimension_name" value="<?php echo e(old('dimension_name')); ?>" required>
                  <?php if ($errors->has('dimension_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dimension_name'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>
                <div class="form-group">
                  <label for="description"><?php echo e(__('app.description')); ?> </label>
                  <textarea type="text" rows="5" class="form-control" id="description" name="description"><?php echo e(old('description')); ?></textarea>           
                </div>                                  
              </div>                

              <div class="col-lg-6 col-md-4 col-sm-12">

              </div>                  
            </div>

          </div>

          <div class="box-footer">
            <a href="<?php echo e(route('dimension.index')); ?>" class="btn btn-default"><?php echo e(__('title.cancel')); ?></a>&nbsp;&nbsp;&nbsp;
            <?php if(Auth::user()->allowCreate(config('global.modules.dimension'))): ?>
            <button type="submit" class="btn btn-primary"><?php echo e(__('title.save')); ?></button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      </div>      
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">   

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/leykamthong/Desktop/projects/selingmix.com/drc/resources/views/setups/dimensions/create.blade.php ENDPATH**/ ?>