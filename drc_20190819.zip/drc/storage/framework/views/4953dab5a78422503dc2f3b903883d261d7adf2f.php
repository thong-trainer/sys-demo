<?php $__env->startSection('css'); ?>
<style type="text/css">
  
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header">
  <h1>
    <?php echo e(__('title.edit_currency')); ?> <small>#<?php echo e($item->id); ?></small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-dashboard"></i><?php echo e(__('title.dashboard')); ?></a></li>
    <li><a href="<?php echo e(route('currency.index')); ?>"><?php echo e(__('title.currencies')); ?></a></li>
    <li class="active"><?php echo e(__('title.edit')); ?></li>
  </ol>
</section>

<section class="content">
  <?php if(session()->has('message')): ?>      
    <div class="alert alert-success alert-dismissible">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <h4><i class="icon fa fa-check"></i> <?php echo e(__('message.success')); ?></h4>
      <?php echo e(session()->get('message')); ?>

    </div>      
  <?php endif; ?>  


  <div class="row">
    <div class="col-md-12">
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title"><i class="fa fa-arrows"></i> <?php echo e(__('title.currency_information')); ?></h3>            
        </div>
        <!-- /.box-header -->
        <div class="box-body">            
          <form role="form" action="<?php echo e(route('currency.update', $item->id)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
            <div class="box-body">    
             <div class="row">
              <div class="col-lg-6 col-md-8 col-sm-12">

                <div class="form-group <?php if ($errors->has('currency')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currency'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                  <label for="currency"><?php echo e(__('app.currency')); ?> <span class="required">*</span></label>
                  <input type="text" class="form-control" id="currency" name="currency" value="<?php echo e(old('currency')?:$item->currency); ?>" required>
                  <?php if ($errors->has('currency')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currency'); ?>
                    <span class="help-block"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                </div>
                <div class="row">
                  <div class="col-md-6 form-group <?php if ($errors->has('symbol')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('symbol'); ?> has-error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                    <label for="symbol"><?php echo e(__('app.symbol')); ?> <span class="required">*</span></label>
                    <input type="text" class="form-control" id="symbol" name="symbol" value="<?php echo e(old('symbol')?:$item->symbol); ?>" placeholder="$" required>
                    <?php if ($errors->has('symbol')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('symbol'); ?>
                      <span class="help-block"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>                      
                  </div>       
                  
                  <div class="col-md-6 form-group">
                    <label for="symbol"><?php echo e(__('app.digit')); ?> <span class="required">*</span></label>
                    <input type="number" class="form-control" id="digit" name="digit" value="<?php echo e(old('digit')?:$item->digit); ?>" min="0" max="4" required>                  
                  </div> 
                </div>
                <div class="row">
                  <div class="col-md-6 form-group">
                    <label for="calculation"><?php echo e(__('app.calculation')); ?></label>
                    <select class="form-control" name="calculation">
                      <option value="">N/A</option>
                      <?php $__currentLoopData = config('global.currency_calculation'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($value); ?>" <?php if($value == old('calculation')): ?> selected <?php elseif($value == $item->calculation): ?> selected <?php endif; ?>><?php echo e($value); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>   
                  </div>
                </div>


                <div class="form-group ">
                  <label for="description"><?php echo e(__('app.description')); ?> <span class="required">*</span></label>
                  <textarea type="text" rows="5" class="form-control" id="description" name="description"><?php echo e(old('description')?:$item->description); ?></textarea>          
                </div>                                  
              </div>                

              <div class="col-lg-6 col-md-4 col-sm-12">
                <div class="box-body table-responsive no-padding">
                  <table class="table table-striped table-hover">
                    <thead>
                      <tr>
                        <th><?php echo e(__('app.exchange_rate')); ?></th>
                        <th><?php echo e(__('app.applied_date')); ?></th>
                        <th style="width: 40px"><?php echo e(__('app.action')); ?></th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $item->rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($rate->rate); ?></td>
                        <td><?php echo e($rate->applied_date); ?></td>
                        <td>
                          <?php if(Auth::user()->allowDelete(config('global.modules.currency'))): ?>                      
                          <a href="#modal-delete-<?php echo e($rate->id); ?>" data-toggle="modal" title="Remove"><i class="fa fa-trash text-danger"></i></a>
                          <div class="modal fade" id="modal-delete-<?php echo e($rate->id); ?>" tabindex="-1" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
                            <div class="modal-dialog">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                  <h4 class="modal-title"><?php echo e(__('title.delete')); ?> - <?php echo e($rate->rate); ?></h4>
                                </div>
                                <div class="modal-body">
                                <?php echo e(__('message.delete_confirmation')); ?>

                                <p class="margin"><i class="fa fa-warning"></i> <?php echo app('translator')->getFromJson('message.delete_warning'); ?> </p>
                                </div>
                                <div class="modal-footer">
                                  <form action="<?php echo e(route('currency.exchange.rate.delete', $rate->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="delete">
                                    <button type="submit" class="btn btn-danger save-cancel"><?php echo e(__('title.yes_delete')); ?></button>
                                    <button type="button" class="btn btn-default save-cancel" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
                                  </form>
                                </div>
                              </div>
                            </div>
                          </div>                          
                          <?php endif; ?>
                        </td>
                      </tr>                  
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td colspan="3">
                          <a href="#modal-rate" data-toggle="modal" title="Add New"><i class="fa fa-plus text-primary new"></i> <?php echo e(__('title.add_new')); ?></a>
                        </td>
                      </tr>                      
                    </tbody>                
                  </table>
                </div>                
              </div>                  
            </div>

          </div>

          <div class="box-footer">
            <a href="<?php echo e(route('currency.index')); ?>" class="btn btn-default"><?php echo e(__('title.cancel')); ?></a>&nbsp;&nbsp;&nbsp;
            <?php if(Auth::user()->allowEdit(config('global.modules.currency'))): ?>
            <button type="submit" class="btn btn-primary"><?php echo e(__('title.save_changes')); ?></button>
            <?php endif; ?>
          </div>
        </form>
      </div>
      </div>      
    </div>
  </div>
</section>
  <div class="modal fade" id="modal-rate" data-keyboard="false" data-backdrop="static" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
      <div id="product-form">
        <form role="form" action="<?php echo e(route('currency.exchange.rate.store')); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="currency_id" value="<?php echo e($item->id); ?>">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
              <h4 class="modal-title"><?php echo e(__('title.add_new')); ?> (<?php echo e(\Auth::user()->defaultCurrency()->currency); ?> <i class="fa fa-arrow-right"></i> <?php echo e($item->currency); ?>)</h4>
            </div>
            <div class="modal-body">
              <div class="form-group">
                <label for="rate"><?php echo e(__('app.exchange_rate')); ?> <span class="required">*</span></label>
                <input type="number" step="any" class="form-control" id="rate" name="rate" value="<?php echo e(old('rate')?: 0); ?>" min="0" required>                   
              </div>
            </div>                   
            <div class="modal-footer">         
              <button type="submit" class="btn btn-primary"><?php echo e(__('title.save')); ?></button>
              <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('title.cancel')); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">   

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\lyly\drc\resources\views/setups/currencies/update.blade.php ENDPATH**/ ?>